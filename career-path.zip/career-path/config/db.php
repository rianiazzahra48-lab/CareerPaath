<?php
require_once __DIR__ . '/../includes/env.php';
require_once __DIR__ . '/../includes/hardening.php';

/**
 * Koneksi MySQL. Pengaturannya dibaca dari file .env (atau pengaturan server).
 * Kalau tidak diisi, dipakai nilai bawaan XAMPP, jadi di komputer lokal tidak perlu diubah apa pun:
 *
 *   MYSQL_HOST=localhost   MYSQL_PORT=3306   MYSQL_DATABASE=career_path
 *   MYSQL_USER=root        MYSQL_PASSWORD=
 *   MYSQL_SSL=true         (hanya bila penyedia database mewajibkan SSL)
 *   MYSQL_SSL_CA=/path/ca.pem   (opsional)   MYSQL_SSL_VERIFY=false (opsional)
 */
function getMysqlConnection(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $host = appEnv('MYSQL_HOST', 'localhost');
    $port = appEnv('MYSQL_PORT', '3306');
    $db   = appEnv('MYSQL_DATABASE', 'career_path');
    $user = appEnv('MYSQL_USER', 'root');
    $pass = appEnv('MYSQL_PASSWORD', '');

    $opsi = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION];
    if (strtolower((string) appEnv('MYSQL_SSL', 'false')) === 'true') {
        $ca = appEnv('MYSQL_SSL_CA');
        if (!$ca && is_readable('/etc/ssl/certs/ca-certificates.crt')) {
            $ca = '/etc/ssl/certs/ca-certificates.crt';
        }
        if ($ca) {
            $opsi[PDO::MYSQL_ATTR_SSL_CA] = $ca;
        }
        $opsi[PDO::MYSQL_ATTR_SSL_VERIFY_SERVER_CERT] = strtolower((string) appEnv('MYSQL_SSL_VERIFY', 'true')) !== 'false';
    }

    try {
        $pdo = new PDO("mysql:host=$host;port=$port;dbname=$db;charset=utf8mb4", $user, $pass, $opsi);
        return $pdo;
    } catch (PDOException $e) {
        error_log('[mysql] ' . $e->getMessage());
        // Di server publik jangan bocorkan alamat/nama pengguna database.
        die(appProduksi() ? 'Koneksi database gagal. Coba lagi beberapa saat lagi.' : 'Koneksi MySQL gagal: ' . $e->getMessage());
    }
}
