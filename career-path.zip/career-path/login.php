<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/layout.php';

if ($sudah = currentUser()) {
    header('Location: ' . homeFor($sudah['role'] ?? ''));
    exit;
}

$error = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();

    $email    = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';

    $pdo = getMysqlConnection();
    $cari = $pdo->prepare('SELECT id, name, email, password_hash, role FROM users WHERE email = ?');
    $cari->execute([$email]);
    $row = $cari->fetch(PDO::FETCH_ASSOC);

    if ($row && password_verify($password, $row['password_hash'])) {
        loginUser($row);
        header('Location: ' . homeFor($row['role']));
        exit;
    }
    // Pesan sengaja sama untuk email salah maupun sandi salah.
    $error = 'Email atau kata sandi salah.';
}

pageHeader('Masuk', [], [], 'auth');
?>
<section class="auth-hero">
    <?= bentuk('auth') ?>
    <div class="card narrow">
    <h1>Masuk</h1>
    <p class="lead">Lanjutkan analisis kariermu.</p>

    <?php if ($error): ?>
        <div class="error"><?= e($error) ?></div>
    <?php endif; ?>

    <form method="post" novalidate>
        <?= csrfField() ?>
        <label for="email">Email</label>
        <input type="email" id="email" name="email" value="<?= e($email) ?>" required>

        <label for="password">Kata sandi</label>
        <input type="password" id="password" name="password" autocomplete="current-password" required>

        <button type="submit">Masuk</button>
    </form>
    <p class="auth-bawah">Belum punya akun? <a href="register.php">Daftar</a></p>
    </div>
</section>
<?php pageFooter(); ?>
