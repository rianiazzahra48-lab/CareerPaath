<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/layout.php';
require_once __DIR__ . '/includes/assessment.php';

$user = requireUser();
$pdo  = getMysqlConnection();

$hitung = function (string $tabel) use ($pdo, $user): int {
    $q = $pdo->prepare("SELECT COUNT(*) FROM $tabel WHERE user_id = ?");
    $q->execute([$user['id']]);
    return (int) $q->fetchColumn();
};
$jumlahSkill = $hitung('user_skills');
$jumlahCert  = $hitung('user_certifications');
$jumlahExp   = $hitung('user_experiences');
$terakhir    = listAssessments($pdo, $user['id'], 1)[0] ?? null;

pageHeader('Beranda', ['assets/result.css']);

$aksi = '<a class="btn ghost" href="profile.php">' . ($jumlahSkill ? 'Ubah profil' : 'Isi profil') . '</a>';
if ($jumlahSkill) {
    $aksi .= '<form method="post" action="analyze.php" class="inline">' . csrfField() . '<button type="submit" class="pink">Analisis karier</button></form>';
}
pageBanner('Halo, ' . $user['name'], 'Lengkapi profilmu supaya rekomendasi kariernya akurat.', $aksi);
?>
<div class="kartu-tiga">
    <div class="card"><b class="angka"><?= $jumlahSkill ?></b><span>skill di profilmu</span></div>
    <div class="card"><b class="angka"><?= $jumlahCert ?></b><span>sertifikasi</span></div>
    <div class="card"><b class="angka"><?= $jumlahExp ?></b><span>pengalaman</span></div>
</div>

<?php if ($terakhir): ?>
    <div class="card">
        <h2 style="margin-top:0">Analisis terakhir</h2>
        <a class="list-row" href="result.php?id=<?= (int) $terakhir['id'] ?>" style="border-top:0; padding:0">
            <div>
                <div class="t"><?= e($terakhir['career_name']) ?></div>
                <div class="d"><?= e(date('d M Y, H:i', strtotime($terakhir['created_at']))) ?> - <?= e($terakhir['label']) ?></div>
            </div>
            <span class="sc"><?= e(number_format((float) $terakhir['score'], 0)) ?>%</span>
        </a>
        <p class="muted" style="margin-bottom:0"><a href="history.php">Lihat semua riwayat</a></p>
    </div>
<?php else: ?>
    <div class="card">
        <h2 style="margin-top:0">Belum ada analisis</h2>
        <p style="margin-bottom:0">Isi skill di profilmu, lalu klik <b>Analisis karier</b> untuk melihat karier yang paling cocok.</p>
    </div>
<?php endif; ?>
<?php pageFooter(); ?>
