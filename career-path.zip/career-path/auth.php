<?php
// Fungsi bantu untuk sesi login. Dipakai oleh semua halaman.

require_once __DIR__ . '/hardening.php';
appBoot(); // header keamanan, mode produksi, dan pembatas percobaan login

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax', 'secure' => appHttps()]);
    session_start();
}

/** Mengamankan teks sebelum ditampilkan di HTML. */
function e(?string $teks): string
{
    return htmlspecialchars((string) $teks, ENT_QUOTES, 'UTF-8');
}

/** Data pengguna yang sedang login, atau null kalau belum login. */
function currentUser(): ?array
{
    return $_SESSION['user'] ?? null;
}

/** Dipakai di halaman yang wajib login. Kalau belum login, dialihkan ke login.php. */
function requireLogin(): array
{
    $user = currentUser();
    if (!$user) {
        header('Location: login.php');
        exit;
    }
    return $user;
}

/** Menandai pengguna sebagai sudah login. */
function loginUser(array $row): void
{
    session_regenerate_id(true);
    $_SESSION['user'] = [
        'id'    => (int) $row['id'],
        'name'  => $row['name'],
        'email' => $row['email'],
        'role'  => $row['role'],
    ];
}

/** Token pengaman formulir (mencegah formulir dikirim dari situs lain). */
function csrfToken(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrfField(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrfToken()) . '">';
}

/** Dipanggil di awal setiap proses formulir POST. */
function csrfCheck(): void
{
    $dikirim = $_POST['csrf'] ?? '';
    if (!hash_equals($_SESSION['csrf'] ?? '', $dikirim)) {
        http_response_code(403);
        exit('Formulir tidak valid. Kembali dan muat ulang halaman.');
    }
}

/**
 * SEMENTARA: pengganti fungsi homeFor() milik auth.php versi sebelumnya (yang tertimpa oleh zip pengamanan).
 * Bila auth.php aslimu sudah dikembalikan, blok ini tidak dipakai karena dijaga function_exists().
 * Fungsi ini menerima array pengguna, teks peran, atau tanpa isi (memakai pengguna yang sedang login).
 */
if (!function_exists('homeFor')) {
    function homeFor($pengguna = null): string
    {
        if ($pengguna === null) {
            $pengguna = currentUser();
        }
        $peran = is_array($pengguna) ? (string) ($pengguna['role'] ?? 'user') : (string) $pengguna;

        if ($peran === 'admin') {
            // Kalau kamu punya halaman dashboard admin, arahkan ke sana.
            foreach (['admin/dashboard.php', 'admin/index.php', 'admin_dashboard.php', 'admin-dashboard.php', 'admin.php'] as $berkas) {
                if (is_file(__DIR__ . '/../' . $berkas)) {
                    return $berkas;
                }
            }
        }
        return 'dashboard.php';
    }
}
