<?php
// Endpoint chatbot. Menerima {"message": "..."} lalu mengembalikan jawaban dalam JSON.
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/chatbot.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function kirimJson(int $kode, array $data): void
{
    http_response_code($kode);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$user = currentUser();
if (!$user) {
    kirimJson(401, ['error' => 'Sesi berakhir. Muat ulang halaman lalu masuk kembali.']);
}
if (($user['role'] ?? '') === 'admin') {
    kirimJson(403, ['error' => 'Chatbot hanya untuk akun pengguna.']);
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    kirimJson(405, ['error' => 'Metode tidak diizinkan.']);
}
if (!hash_equals($_SESSION['csrf'] ?? '', $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '')) {
    kirimJson(403, ['error' => 'Token keamanan tidak valid. Muat ulang halaman.']);
}

// Pembatas: maksimal 20 pesan per menit per sesi
$sekarang = time();
$riwayat = array_filter($_SESSION['chat_waktu'] ?? [], fn($w) => $w > $sekarang - 60);
if (count($riwayat) >= 20) {
    kirimJson(429, ['error' => 'Terlalu banyak pesan. Tunggu sebentar lalu coba lagi.']);
}
$riwayat[] = $sekarang;
$_SESSION['chat_waktu'] = array_values($riwayat);

$badan = json_decode((string) file_get_contents('php://input'), true);
$pesan = mb_substr(trim((string) ($badan['message'] ?? '')), 0, 300);

try {
    kirimJson(200, botJawab(getMysqlConnection(), $user, $pesan));
} catch (Throwable $err) {
    error_log('[chatbot] ' . $err->getMessage());
    kirimJson(500, ['error' => 'Maaf, asisten sedang bermasalah. Coba lagi sebentar.']);
}
