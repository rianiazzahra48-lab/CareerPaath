<?php
require_once __DIR__ . '/includes/auth.php';

// Keluar hanya lewat tombol (POST) yang punya token pengaman.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $_SESSION = [];
    session_destroy();
}
header('Location: login.php');
exit;
