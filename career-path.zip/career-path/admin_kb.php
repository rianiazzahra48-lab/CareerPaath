<?php
// Admin: kelola knowledge base (karier, skill, sertifikasi, bobot penilaian) di MongoDB.
// Setelah karier atau skill berubah, indeks pencarian Qdrant diperbarui otomatis.
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/admin.php';
require_once __DIR__ . '/includes/kb_admin.php';

$pdo  = getMysqlConnection();
$user = requireAdmin($pdo);

const KB_TAB = ['careers' => 'Karier', 'skills' => 'Skill', 'certs' => 'Sertifikasi', 'config' => 'Bobot penilaian'];
const KB_KOLEKSI = ['careers' => 'careers', 'skills' => 'skills', 'certs' => 'certifications'];

/** Pesan setelah menyimpan atau menghapus. Karier dan skill ikut memperbarui indeks Qdrant. */
function kbPesanSelesai(string $apa, bool $perluIndeks): void
{
    if (!$perluIndeks) {
        flashSet('ok', $apa);
        return;
    }
    $gagal = kaIsiUlangQdrant();
    if ($gagal === null) {
        flashSet('ok', $apa . ' Indeks pencarian Qdrant sudah diperbarui.');
    } else {
        flashSet('ok', $apa);
        flashSet('warn', 'Indeks Qdrant belum diperbarui: ' . $gagal . ' Coba lagi lewat menu Indeks Qdrant.');
    }
}

$tab = (string) ($_POST['tab'] ?? $_GET['tab'] ?? 'careers');
if (!array_key_exists($tab, KB_TAB)) {
    $tab = 'careers';
}

$errors = [];
$form   = null;
$aksi   = '';
$baru   = false;
$post   = $_SERVER['REQUEST_METHOD'] === 'POST';

/* ================= Memproses formulir ================= */
if ($post) {
    csrfCheck();
    @set_time_limit(120);
    $aksi = (string) ($_POST['aksi'] ?? '');
    $baru = ($_POST['baru'] ?? '') === '1';

    // Catatan: sebelum indeks Qdrant dibangun ulang, jangan memanggil kbSkills() atau kbCareers()
    // (hasilnya disimpan sementara dan bisa jadi data lama). Di sini hanya fungsi ka*() yang dipakai.
    try {
        if ($aksi === 'hapus' && $tab !== 'config') {
            $kode = kaTeks($_POST['code'] ?? '', 40);
            $err  = kaHapus(KB_KOLEKSI[$tab], $kode);
            if ($err) {
                flashSet('error', implode(' ', $err));
            } else {
                kbPesanSelesai('Data dihapus.', $tab !== 'certs');
            }
            header('Location: admin_kb.php?tab=' . $tab);
            exit;
        }

        if ($aksi === 'simpan') {
            if ($tab === 'config') {
                $form   = kaBacaFormConfig($_POST);
                $errors = kaSimpanConfig($form);
                if (!$errors) {
                    flashSet('ok', 'Bobot penilaian disimpan. Analisis berikutnya memakai bobot yang baru.');
                    header('Location: admin_kb.php?tab=config');
                    exit;
                }
            } else {
                if ($tab === 'skills') {
                    $form = kaBacaFormSkill($_POST);
                } elseif ($tab === 'certs') {
                    $form = kaBacaFormCert($_POST);
                } else {
                    $form = kaBacaFormKarier($_POST, kaSemua('skills'), kaSemua('certifications'));
                }
                if ($baru) {
                    $form['code'] = strtolower($form['code']);
                }

                if ($tab === 'skills') {
                    $errors = kaSimpanSkill($form, $baru);
                } elseif ($tab === 'certs') {
                    $errors = kaSimpanCert($form, $baru);
                } else {
                    $errors = kaSimpanKarier($form, $baru);
                }

                if (!$errors) {
                    kbPesanSelesai('Data disimpan.', $tab !== 'certs');
                    header('Location: admin_kb.php?tab=' . $tab);
                    exit;
                }
            }
        }
    } catch (Throwable $err) {
        $errors = ['Terjadi kesalahan: ' . $err->getMessage()];
    }
}

/* ================= Menentukan tampilan ================= */
$mode     = 'daftar';   // daftar, baru, atau edit
$kodeEdit = '';
if ($post) {
    if ($errors && $aksi === 'simpan') {
        $mode     = $baru ? 'baru' : 'edit';
        $kodeEdit = (string) ($form['code'] ?? '');
    }
} elseif (isset($_GET['baru'])) {
    $mode = 'baru';
} elseif (isset($_GET['edit'])) {
    $mode     = 'edit';
    $kodeEdit = kaTeks($_GET['edit'], 40);
}
if ($tab === 'config') {
    $mode = 'edit';
}

/* ================= Membaca data untuk ditampilkan ================= */
$semuaSkill = $semuaCert = $semuaKarier = [];
$errBaca = '';
try {
    $semuaSkill  = kaSemua('skills');
    $semuaCert   = kaSemua('certifications');
    $semuaKarier = kaSemua('careers');
} catch (Throwable $err) {
    $errBaca = $err->getMessage();
}

// isi formulir: dari kiriman (kalau ada kesalahan), dari data lama (ubah), atau kosong (baru)
if ($form === null && !$errBaca) {
    if ($tab === 'config') {
        try {
            $form = kaConfigSekarang();
        } catch (Throwable $err) {
            $errBaca = $err->getMessage();
        }
    } elseif ($mode === 'edit') {
        $sumber = ['careers' => $semuaKarier, 'skills' => $semuaSkill, 'certs' => $semuaCert][$tab];
        foreach ($sumber as $dok) {
            if ((string) $dok['_id'] === $kodeEdit) {
                $form = $dok + ['code' => (string) $dok['_id']];
                break;
            }
        }
        if ($form === null) {
            $errors[] = 'Data yang mau diubah tidak ditemukan.';
            $mode = 'daftar';
        }
    }
}
if ($form === null) {
    $form = ['code' => '', 'name' => '', 'description' => '', 'category' => '', 'issuer' => '', 'minEducation' => 3,
             'idealExperienceYears' => 1, 'preferredMajors' => [], 'experienceKeywords' => [], 'requirements' => [], 'certifications' => []];
}

// jumlah karier yang memakai tiap skill dan sertifikasi
$pakaiSkill = $pakaiCert = [];
foreach ($semuaKarier as $k) {
    foreach ((array) ($k['requirements'] ?? []) as $r) {
        $kode = (string) ($r['skillCode'] ?? '');
        $pakaiSkill[$kode] = ($pakaiSkill[$kode] ?? 0) + 1;
    }
    foreach ((array) ($k['certifications'] ?? []) as $r) {
        $kode = (string) ($r['certCode'] ?? '');
        $pakaiCert[$kode] = ($pakaiCert[$kode] ?? 0) + 1;
    }
}

/** Formulir kecil untuk tombol Hapus. */
function kbTombolHapus(string $tab, string $kode): void
{
    ?>
    <form method="post" class="inline" onsubmit="return confirm('Hapus data ini?');">
        <?= csrfField() ?>
        <input type="hidden" name="tab" value="<?= e($tab) ?>">
        <input type="hidden" name="aksi" value="hapus">
        <input type="hidden" name="code" value="<?= e($kode) ?>">
        <button type="submit" class="small danger">Hapus</button>
    </form>
    <?php
}

/** Bagian atas setiap formulir: token pengaman dan penanda jenis proses. */
function kbBagianAtasForm(string $tab, bool $baru, string $kode): void
{
    echo csrfField();
    echo '<input type="hidden" name="tab" value="' . e($tab) . '">';
    echo '<input type="hidden" name="aksi" value="simpan">';
    echo '<input type="hidden" name="baru" value="' . ($baru ? '1' : '0') . '">';
    if (!$baru) {
        echo '<input type="hidden" name="code" value="' . e($kode) . '">';
    }
}

/** Kotak kode: bisa diisi untuk data baru, hanya-baca untuk data yang diubah. */
function kbKolomKode(bool $baru, string $kode, string $contoh): void
{
    ?>
    <label for="f-code">Kode</label>
    <input type="text" id="f-code" <?= $baru ? 'name="code"' : 'readonly' ?> value="<?= e($kode) ?>" maxlength="40" placeholder="mis. <?= e($contoh) ?>" <?= $baru ? 'required' : '' ?>>
    <p class="hint"><?= $baru ? 'Huruf kecil, angka, tanda - atau _. Tidak bisa diubah setelah disimpan.' : 'Kode tidak bisa diubah.' ?></p>
    <?php
}

pageHeader('Kelola knowledge base', ['assets/profile.css', 'assets/result.css', 'assets/admin.css']);
?>
<?php pageBanner('Kelola knowledge base', 'Di sini kamu "mengajari" sistem: karier apa saja yang ada, skill apa yang dibutuhkan, dan bagaimana skor dihitung.'); ?>
<?php adminNav('kb'); ?>
<?php flashShow(); ?>

<nav class="admin-nav" aria-label="Jenis data">
    <?php foreach (KB_TAB as $kunci => $label): ?>
        <a href="admin_kb.php?tab=<?= e($kunci) ?>"<?= $kunci === $tab ? ' class="on"' : '' ?>><?= e($label) ?></a>
    <?php endforeach; ?>
</nav>

<?php adminErrors($errors); ?>
<?php if ($errBaca): ?>
    <div class="error">MongoDB belum bisa dibaca: <?= e($errBaca) ?></div>
    <?php pageFooter(); exit; ?>
<?php endif; ?>

<?php /* ---------------- BOBOT PENILAIAN ---------------- */ ?>
<?php if ($tab === 'config'): ?>
    <div class="card">
        <h2>Bobot penilaian</h2>
        <p class="hint2">Skor kecocokan dihitung dari empat bagian. Bobot tidak harus berjumlah 1, karena mesin menyesuaikan sendiri.</p>
        <form method="post">
            <?php kbBagianAtasForm('config', false, ''); ?>
            <div class="grid4">
                <div><label for="w1">Skill</label><input type="number" id="w1" name="weight_skill" step="0.01" min="0" max="1" value="<?= e((string) $form['weight_skill']) ?>"></div>
                <div><label for="w2">Pendidikan</label><input type="number" id="w2" name="weight_education" step="0.01" min="0" max="1" value="<?= e((string) $form['weight_education']) ?>"></div>
                <div><label for="w3">Pengalaman</label><input type="number" id="w3" name="weight_experience" step="0.01" min="0" max="1" value="<?= e((string) $form['weight_experience']) ?>"></div>
                <div><label for="w4">Sertifikasi</label><input type="number" id="w4" name="weight_certification" step="0.01" min="0" max="1" value="<?= e((string) $form['weight_certification']) ?>"></div>
            </div>
            <h2 style="margin-top:8px">Batas tingkat kecocokan</h2>
            <p class="hint2">Skor di atas batas "tinggi" diberi label paling atas, dan seterusnya. Urutannya harus tinggi &gt; sedang &gt; rendah.</p>
            <div class="grid4">
                <div><label for="t1">Tinggi (0-100)</label><input type="number" id="t1" name="threshold_high" step="1" min="0" max="100" value="<?= e((string) $form['threshold_high']) ?>"></div>
                <div><label for="t2">Sedang (0-100)</label><input type="number" id="t2" name="threshold_medium" step="1" min="0" max="100" value="<?= e((string) $form['threshold_medium']) ?>"></div>
                <div><label for="t3">Rendah (0-100)</label><input type="number" id="t3" name="threshold_low" step="1" min="0" max="100" value="<?= e((string) $form['threshold_low']) ?>"></div>
                <div><label for="t4">Jumlah rekomendasi</label><input type="number" id="t4" name="top_n" step="1" min="1" max="20" value="<?= e((string) $form['top_n']) ?>"></div>
            </div>
            <div class="form-actions"><button type="submit">Simpan bobot</button></div>
        </form>
    </div>

<?php /* ---------------- DAFTAR ---------------- */ ?>
<?php elseif ($mode === 'daftar'): ?>
    <div class="toolbar">
        <span class="muted" style="margin:0"><?= count($tab === 'careers' ? $semuaKarier : ($tab === 'skills' ? $semuaSkill : $semuaCert)) ?> data</span>
        <a class="btn" href="admin_kb.php?tab=<?= e($tab) ?>&amp;baru=1">Tambah <?= e(strtolower(KB_TAB[$tab])) ?></a>
    </div>
    <div class="card tbl-wrap">
    <?php if ($tab === 'careers'): ?>
        <table class="tbl">
            <tr><th>Karier</th><th>Pendidikan minimal</th><th>Skill</th><th>Sertifikasi</th><th></th></tr>
            <?php foreach ($semuaKarier as $k): $kode = (string) $k['_id']; ?>
                <tr>
                    <td><b><?= e((string) ($k['name'] ?? $kode)) ?></b><small class="code"><?= e($kode) ?></small></td>
                    <td><?= e(NAMA_JENJANG_KB[(int) ($k['minEducation'] ?? 3)] ?? '-') ?></td>
                    <td><?= count((array) ($k['requirements'] ?? [])) ?></td>
                    <td><?= count((array) ($k['certifications'] ?? [])) ?></td>
                    <td class="act">
                        <a class="btn ghost small" href="admin_kb.php?tab=careers&amp;edit=<?= e(rawurlencode($kode)) ?>">Ubah</a>
                        <?php kbTombolHapus('careers', $kode); ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php elseif ($tab === 'skills'): ?>
        <table class="tbl">
            <tr><th>Skill</th><th>Kategori</th><th>Dipakai karier</th><th></th></tr>
            <?php foreach ($semuaSkill as $s): $kode = (string) $s['_id']; ?>
                <tr>
                    <td><b><?= e((string) ($s['name'] ?? $kode)) ?></b><small class="code"><?= e($kode) ?></small></td>
                    <td><?= e((string) ($s['category'] ?? '')) ?></td>
                    <td><?= (int) ($pakaiSkill[$kode] ?? 0) ?></td>
                    <td class="act">
                        <a class="btn ghost small" href="admin_kb.php?tab=skills&amp;edit=<?= e(rawurlencode($kode)) ?>">Ubah</a>
                        <?php kbTombolHapus('skills', $kode); ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <table class="tbl">
            <tr><th>Sertifikasi</th><th>Penerbit</th><th>Dipakai karier</th><th></th></tr>
            <?php foreach ($semuaCert as $c): $kode = (string) $c['_id']; ?>
                <tr>
                    <td><b><?= e((string) ($c['name'] ?? $kode)) ?></b><small class="code"><?= e($kode) ?></small></td>
                    <td><?= e((string) ($c['issuer'] ?? '')) ?></td>
                    <td><?= (int) ($pakaiCert[$kode] ?? 0) ?></td>
                    <td class="act">
                        <a class="btn ghost small" href="admin_kb.php?tab=certs&amp;edit=<?= e(rawurlencode($kode)) ?>">Ubah</a>
                        <?php kbTombolHapus('certs', $kode); ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>
    </div>
    <p class="muted">Setiap kali karier atau skill disimpan atau dihapus, indeks pencarian Qdrant ikut diperbarui otomatis. Prosesnya beberapa detik.</p>

<?php /* ---------------- FORM SKILL ---------------- */ ?>
<?php elseif ($tab === 'skills'): ?>
    <?php $kategori = array_values(array_filter(array_unique(array_map(fn($s) => (string) ($s['category'] ?? ''), $semuaSkill)), fn($x) => $x !== '')); ?>
    <div class="card">
        <h2><?= $mode === 'baru' ? 'Tambah skill' : 'Ubah skill' ?></h2>
        <form method="post">
            <?php kbBagianAtasForm('skills', $mode === 'baru', (string) ($form['code'] ?? '')); ?>
            <?php kbKolomKode($mode === 'baru', (string) ($form['code'] ?? ''), 'figma'); ?>
            <label for="f-name">Nama skill</label>
            <input type="text" id="f-name" name="name" value="<?= e((string) ($form['name'] ?? '')) ?>" maxlength="100" required>
            <label for="f-cat">Kategori</label>
            <input type="text" id="f-cat" name="category" value="<?= e((string) ($form['category'] ?? '')) ?>" maxlength="60" list="daftar-kategori" placeholder="mis. Desain">
            <datalist id="daftar-kategori">
                <?php foreach ($kategori as $kat): ?><option value="<?= e($kat) ?>"><?php endforeach; ?>
            </datalist>
            <label for="f-tip">Tips belajar (boleh kosong)</label>
            <textarea id="f-tip" name="learningTip" maxlength="500"><?= e((string) ($form['learningTip'] ?? '')) ?></textarea>
            <label for="f-url">Tautan belajar (boleh kosong)</label>
            <input type="url" id="f-url" name="learningUrl" value="<?= e((string) ($form['learningUrl'] ?? '')) ?>" maxlength="300" placeholder="https://...">
            <div class="form-actions">
                <button type="submit">Simpan skill</button>
                <a class="btn ghost" href="admin_kb.php?tab=skills">Batal</a>
            </div>
        </form>
    </div>

<?php /* ---------------- FORM SERTIFIKASI ---------------- */ ?>
<?php elseif ($tab === 'certs'): ?>
    <div class="card">
        <h2><?= $mode === 'baru' ? 'Tambah sertifikasi' : 'Ubah sertifikasi' ?></h2>
        <form method="post">
            <?php kbBagianAtasForm('certs', $mode === 'baru', (string) ($form['code'] ?? '')); ?>
            <?php kbKolomKode($mode === 'baru', (string) ($form['code'] ?? ''), 'psm1'); ?>
            <label for="f-name">Nama sertifikasi</label>
            <input type="text" id="f-name" name="name" value="<?= e((string) ($form['name'] ?? '')) ?>" maxlength="150" required>
            <label for="f-issuer">Penerbit</label>
            <input type="text" id="f-issuer" name="issuer" value="<?= e((string) ($form['issuer'] ?? '')) ?>" maxlength="100" placeholder="mis. Scrum.org">
            <div class="form-actions">
                <button type="submit">Simpan sertifikasi</button>
                <a class="btn ghost" href="admin_kb.php?tab=certs">Batal</a>
            </div>
        </form>
    </div>

<?php /* ---------------- FORM KARIER ---------------- */ ?>
<?php else: ?>
    <?php
    $reqMap = [];
    foreach ((array) ($form['requirements'] ?? []) as $r) {
        $reqMap[(string) ($r['skillCode'] ?? '')] = $r;
    }
    $certMap = [];
    foreach ((array) ($form['certifications'] ?? []) as $r) {
        $certMap[(string) ($r['certCode'] ?? '')] = $r;
    }
    $skillUrut = $semuaSkill;
    usort($skillUrut, fn($a, $b) => strcasecmp((string) ($a['category'] ?? ''), (string) ($b['category'] ?? '')) ?: strcasecmp((string) ($a['name'] ?? ''), (string) ($b['name'] ?? '')));

    $opsiLevel = [0 => 'Tidak dibutuhkan'];
    foreach (KA_LEVEL as $n => $nama) {
        $opsiLevel[$n] = $n . ' - ' . $nama;
    }
    $opsiBobot = [];
    for ($i = 1; $i <= 10; $i++) {
        $opsiBobot[$i] = (string) $i;
    }
    ?>
    <form method="post">
        <?php kbBagianAtasForm('careers', $mode === 'baru', (string) ($form['code'] ?? '')); ?>

        <div class="card">
            <h2><?= $mode === 'baru' ? 'Tambah karier' : 'Ubah karier' ?></h2>
            <?php kbKolomKode($mode === 'baru', (string) ($form['code'] ?? ''), 'data-analyst'); ?>
            <label for="f-name">Nama karier</label>
            <input type="text" id="f-name" name="name" value="<?= e((string) ($form['name'] ?? '')) ?>" maxlength="100" required>
            <label for="f-desc">Deskripsi singkat</label>
            <textarea id="f-desc" name="description" maxlength="1000" required><?= e((string) ($form['description'] ?? '')) ?></textarea>
            <div class="grid2">
                <div>
                    <label for="f-edu">Pendidikan minimal</label>
                    <select id="f-edu" name="minEducation"><?= adminOpsi(NAMA_JENJANG_KB, (int) ($form['minEducation'] ?? 3)) ?></select>
                </div>
                <div>
                    <label for="f-years">Pengalaman ideal (tahun)</label>
                    <input type="number" id="f-years" name="idealExperienceYears" step="0.5" min="0" max="30" value="<?= e((string) ($form['idealExperienceYears'] ?? 1)) ?>">
                </div>
            </div>
            <div class="grid2">
                <div>
                    <label for="f-maj">Jurusan yang cocok (satu per baris)</label>
                    <textarea id="f-maj" name="preferredMajors"><?= e(implode("\n", (array) ($form['preferredMajors'] ?? []))) ?></textarea>
                </div>
                <div>
                    <label for="f-kw">Kata kunci pengalaman (satu per baris)</label>
                    <textarea id="f-kw" name="experienceKeywords"><?= e(implode("\n", (array) ($form['experienceKeywords'] ?? []))) ?></textarea>
                </div>
            </div>
            <p class="hint2">Kata kunci dicocokkan dengan pengalaman kerja pengguna, misalnya "analis" atau "data".</p>
        </div>

        <div class="card">
            <h2>Skill yang dibutuhkan</h2>
            <p class="hint2">Pilih level yang dibutuhkan untuk tiap skill. Biarkan "Tidak dibutuhkan" untuk skill yang tidak relevan. Bobot 1-10: makin besar makin penting.</p>
            <div class="tbl-wrap">
                <table class="tbl">
                    <tr><th>Skill</th><th>Level dibutuhkan</th><th>Bobot</th></tr>
                    <?php foreach ($skillUrut as $s): $kode = (string) $s['_id']; $r = $reqMap[$kode] ?? null; ?>
                        <tr>
                            <td><?= e((string) ($s['name'] ?? $kode)) ?><small><?= e((string) ($s['category'] ?? '')) ?></small></td>
                            <td><select name="req_level[<?= e($kode) ?>]" aria-label="Level <?= e((string) ($s['name'] ?? $kode)) ?>"><?= adminOpsi($opsiLevel, $r ? (int) $r['requiredLevel'] : 0) ?></select></td>
                            <td><select name="req_weight[<?= e($kode) ?>]" aria-label="Bobot <?= e((string) ($s['name'] ?? $kode)) ?>"><?= adminOpsi($opsiBobot, $r ? (int) $r['weight'] : 3) ?></select></td>
                        </tr>
                    <?php endforeach; ?>
                </table>
            </div>
        </div>

        <div class="card">
            <h2>Sertifikasi yang menambah nilai</h2>
            <p class="hint2">Centang sertifikasi yang relevan. Bobot bonus 1-10: makin besar makin berpengaruh.</p>
            <div class="tbl-wrap">
                <table class="tbl">
                    <tr><th>Pakai</th><th>Sertifikasi</th><th>Bobot bonus</th></tr>
                    <?php foreach ($semuaCert as $c): $kode = (string) $c['_id']; $r = $certMap[$kode] ?? null; ?>
                        <tr>
                            <td><input type="checkbox" name="cert_use[<?= e($kode) ?>]" value="1" <?= $r ? 'checked' : '' ?> aria-label="Pakai <?= e((string) ($c['name'] ?? $kode)) ?>"></td>
                            <td><?= e((string) ($c['name'] ?? $kode)) ?><small><?= e((string) ($c['issuer'] ?? '')) ?></small></td>
                            <td><select name="cert_bonus[<?= e($kode) ?>]" aria-label="Bobot bonus <?= e((string) ($c['name'] ?? $kode)) ?>"><?= adminOpsi($opsiBobot, $r ? (int) $r['bonusWeight'] : 2) ?></select></td>
                        </tr>
                    <?php endforeach; ?>
                </table>
            </div>
        </div>

        <div class="form-actions">
            <button type="submit">Simpan karier</button>
            <a class="btn ghost" href="admin_kb.php?tab=careers">Batal</a>
        </div>
        <p class="muted">Setelah disimpan, indeks pencarian Qdrant diperbarui otomatis. Prosesnya beberapa detik.</p>
    </form>
<?php endif; ?>
<?php pageFooter(); ?>
