<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/layout.php';
require_once __DIR__ . '/includes/kb.php';
require_once __DIR__ . '/includes/profile_repo.php';
require_once __DIR__ . '/includes/assessment.php';

$user   = requireUser();
$pdo    = getMysqlConnection();
$skills = kbSkills();        // dari MongoDB
$certs  = kbCertifications(); // dari MongoDB

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    saveProfile($pdo, $user['id'], readProfileForm($_POST, $skills, $certs));

    if (($_POST['lanjut'] ?? '') === 'analisis') {
        $idAnalisis = runAssessment($pdo, $user['id']);
        header('Location: ' . ($idAnalisis ? 'result.php?id=' . $idAnalisis : 'profile.php?perlu_skill=1'));
        exit;
    }
    header('Location: profile.php?tersimpan=1');
    exit;
}

$profil = loadProfile($pdo, $user['id']);

$jenjang = [1 => 'SMA/SMK', 2 => 'Diploma (D3)', 3 => 'Sarjana (S1/D4)', 4 => 'Magister (S2)', 5 => 'Doktor (S3)'];
$namaLevel = [1 => 'Mengenal', 2 => 'Dasar', 3 => 'Menengah', 4 => 'Mahir', 5 => 'Ahli'];

// kelompokkan skill per kategori
$perKategori = [];
foreach ($skills as $s) {
    $perKategori[$s['category']][] = $s;
}

function barisPengalaman(array $e = []): string
{
    ob_start(); ?>
    <div class="exp-item">
        <div class="grid3">
            <div><label>Posisi / peran</label>
                <input type="text" name="exp_title[]" value="<?= e($e['title'] ?? '') ?>" maxlength="150" placeholder="mis. Magang Analis Sistem"></div>
            <div><label>Perusahaan / organisasi</label>
                <input type="text" name="exp_company[]" value="<?= e($e['company'] ?? '') ?>" maxlength="150"></div>
            <div><label>Lama (tahun)</label>
                <input type="text" name="exp_years[]" value="<?= e((string) ($e['years'] ?? '')) ?>" inputmode="decimal" placeholder="mis. 1.5"></div>
        </div>
        <label>Yang kamu kerjakan</label>
        <textarea name="exp_desc[]" maxlength="2000" placeholder="Kata seperti analis, data, web, atau desain membantu pencocokan."><?= e($e['description'] ?? '') ?></textarea>
    </div>
    <?php
    return ob_get_clean();
}

pageHeader('Profil', ['assets/profile.css'], ['assets/profile.js']);
?>
<?php pageBanner('Profil kompetensimu', 'Isi sejujur mungkin. Hasil analisis hanya sebaik data yang kamu masukkan.'); ?>

<?php if (isset($_GET['tersimpan'])): ?>
    <div class="ok">Profil tersimpan.</div>
<?php endif; ?>
<?php if (isset($_GET['perlu_skill'])): ?>
    <div class="error">Pilih minimal satu skill dulu, baru analisis bisa dijalankan.</div>
<?php endif; ?>

<form method="post" novalidate>
    <?= csrfField() ?>

    <section class="card">
        <h2>Pendidikan</h2>
        <div class="grid2">
            <div>
                <label for="edu">Jenjang terakhir</label>
                <select id="edu" name="education_level">
                    <?php foreach ($jenjang as $v => $nama): ?>
                        <option value="<?= $v ?>" <?= $v === $profil['education_level'] ? 'selected' : '' ?>><?= e($nama) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label for="major">Jurusan / program studi</label>
                <input type="text" id="major" name="major" value="<?= e($profil['major']) ?>" maxlength="120" placeholder="mis. Sistem Informasi">
            </div>
        </div>
        <label for="headline">Ringkasan tentang dirimu (boleh dikosongkan)</label>
        <input type="text" id="headline" name="headline" value="<?= e($profil['headline']) ?>" maxlength="200">
    </section>

    <section class="card">
        <h2>Skill</h2>
        <p class="hint2">Klik kotak untuk memilih level. Makin ke kanan makin tinggi:
            1 = <?= e($namaLevel[1]) ?>, 3 = <?= e($namaLevel[3]) ?>, 5 = <?= e($namaLevel[5]) ?>.
            Klik <b>kosongkan</b> untuk membatalkan.</p>

        <?php foreach ($perKategori as $kategori => $daftar): ?>
            <details class="cat" open>
                <summary><?= e($kategori) ?></summary>
                <?php foreach ($daftar as $s):
                    $kode  = $s['code'];
                    $level = $profil['skills'][$kode] ?? 0; ?>
                    <div class="skill-row">
                        <span class="skill-name"><?= e($s['name']) ?></span>
                        <div class="lvl" role="radiogroup" aria-label="Level <?= e($s['name']) ?>">
                            <?php for ($n = 5; $n >= 1; $n--): ?>
                                <input type="radio" name="skill[<?= e($kode) ?>]" id="s_<?= e($kode) ?>_<?= $n ?>" value="<?= $n ?>" <?= $level === $n ? 'checked' : '' ?>>
                                <label class="seg" for="s_<?= e($kode) ?>_<?= $n ?>" title="<?= $n ?> - <?= e($namaLevel[$n]) ?>"></label>
                            <?php endfor; ?>
                            <input type="radio" name="skill[<?= e($kode) ?>]" id="s_<?= e($kode) ?>_0" value="0" <?= $level === 0 ? 'checked' : '' ?>>
                            <label class="clear" for="s_<?= e($kode) ?>_0">kosongkan</label>
                        </div>
                    </div>
                <?php endforeach; ?>
            </details>
        <?php endforeach; ?>
    </section>

    <section class="card">
        <h2>Sertifikasi</h2>
        <p class="hint2">Centang yang sudah kamu miliki.</p>
        <div class="cert-grid">
            <?php foreach ($certs as $c): ?>
                <label class="check">
                    <input type="checkbox" name="cert[]" value="<?= e($c['code']) ?>" <?= in_array($c['code'], $profil['certs'], true) ? 'checked' : '' ?>>
                    <span><?= e($c['name']) ?><small><?= e($c['issuer']) ?></small></span>
                </label>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="card">
        <h2>Pengalaman</h2>
        <p class="hint2">Magang, kerja, freelance, atau organisasi. Untuk menghapus satu pengalaman, kosongkan kolom posisinya lalu simpan.</p>
        <div id="exp-list">
            <?php
            foreach ($profil['experiences'] as $e) {
                echo barisPengalaman($e);
            }
            if (!$profil['experiences']) {
                echo barisPengalaman();
            }
            ?>
        </div>
        <template id="exp-template"><?= barisPengalaman() ?></template>
        <button type="button" class="ghost" id="exp-add">Tambah pengalaman</button>
    </section>

    <div class="savebar">
        <div class="savebar-in">
            <span id="skill-count" class="muted-count"></span>
            <button type="submit" class="ghost">Simpan profil</button>
            <button type="submit" name="lanjut" value="analisis">Simpan dan analisis karier</button>
        </div>
    </div>
</form>
<?php pageFooter(); ?>
