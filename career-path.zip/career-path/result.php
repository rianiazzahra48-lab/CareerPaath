<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/layout.php';
require_once __DIR__ . '/includes/assessment.php';

$user = requireUser();
$a = getAssessment(getMysqlConnection(), $user['id'], (int) ($_GET['id'] ?? 0));
if (!$a) {
    http_response_code(404);
    pageHeader('Tidak ditemukan');
    echo '<div class="card"><h1>Hasil tidak ditemukan</h1><p><a href="history.php">Lihat riwayat analisis</a></p></div>';
    pageFooter();
    exit;
}

const KELAS_LABEL = ['Sangat Cocok' => 'high', 'Cocok' => 'medium', 'Cukup Cocok' => 'low', 'Perlu Pengembangan' => 'none'];
const TEKS_STATUS = ['strong' => 'Sudah kuat', 'partial' => 'Perlu ditingkatkan', 'missing' => 'Belum dimiliki'];

function persen(float $n): string
{
    return (int) round($n) . '%';
}

/** 5 kotak: terisi = level kamu, garis merah = kekurangan, garis hitam = level yang dibutuhkan. */
function meter(int $levelUser, int $dibutuhkan): string
{
    $html = '<span class="meter" role="img" aria-label="Level kamu ' . $levelUser . ', dibutuhkan ' . $dibutuhkan . '">';
    for ($n = 1; $n <= 5; $n++) {
        $kelas = $n <= $levelUser ? 'on' : ($n <= $dibutuhkan ? 'need' : '');
        if ($n === $dibutuhkan) {
            $kelas .= ' mark';
        }
        $html .= '<i class="' . trim($kelas) . '"></i>';
    }
    return $html . '</span>';
}

function bagianSkor(string $judul, array $b, string $catatan): string
{
    return '<div class="part"><div class="row"><span>' . e($judul) . ' <small>(bobot ' . (int) $b['weightPct'] . '%)</small></span>'
        . '<b>' . persen($b['score']) . '</b></div><div class="bar"><span style="width:' . (float) $b['score'] . '%"></span></div>'
        . '<small>' . e($catatan) . '</small></div>';
}

function amanUrl(?string $url): string
{
    return preg_match('#^https?://#i', (string) $url) ? (string) $url : '';
}

$atas = $a['results'][0] ?? null;

pageHeader('Hasil analisis', ['assets/result.css']);
?>
<?php
pageBanner(
    $atas ? 'Paling cocok: ' . $atas['careerName'] : 'Hasil analisis',
    'Dianalisis pada ' . date('d M Y, H:i', strtotime($a['created_at'])) . '. Buka tiap posisi untuk melihat rincian skor dan skill gap-nya.',
    '<a class="btn ghost" href="profile.php">Ubah profil</a>'
    . '<form method="post" action="analyze.php" class="inline">' . csrfField() . '<button type="submit" class="pink">Analisis ulang</button></form>'
);
?>

<div class="card legend">
    <span>Cara membaca meter:</span>
    <span><span class="meter"><i class="on"></i></span> level yang kamu punya</span>
    <span><span class="meter"><i class="need"></i></span> kekurangan untuk mencapai level yang dibutuhkan</span>
    <span><span class="meter"><i class="mark"></i></span> garis hitam = level yang dibutuhkan</span>
</div>

<div class="trail">
<?php foreach ($a['results'] as $r):
    $lv = KELAS_LABEL[$r['label']] ?? 'none';
    $b  = $r['breakdown'];
    $totalSkill = count($r['skills']);
    ?>
    <details class="career lv-<?= e($lv) ?><?= $r['rank'] === 1 ? ' top' : '' ?>" <?= $r['rank'] === 1 ? 'open' : '' ?>>
        <summary>
            <div class="ring" style="--p:<?= (float) $r['score'] ?>"><span><?= persen($r['score']) ?></span></div>
            <div class="c-head">
                <span class="rank">Peringkat <?= (int) $r['rank'] ?></span>
                <h3><?= e($r['careerName']) ?></h3>
                <span class="pill <?= e($lv) ?>"><?= e($r['label']) ?></span>
            </div>
            <span class="chev" aria-hidden="true"></span>
        </summary>
        <div class="c-body">
            <?php if ($r['description']): ?><p class="desc"><?= e($r['description']) ?></p><?php endif; ?>
            <p class="summary"><?= e($r['summary']) ?></p>

            <h4>Dari mana skor ini datang</h4>
            <div class="parts">
                <?= bagianSkor('Skill', $b['skills'], count($r['strengths']) . " dari $totalSkill skill utama sudah memenuhi level yang dibutuhkan") ?>
                <?= bagianSkor('Pendidikan', $b['education'],
                    ($b['education']['levelMet'] ? 'Jenjang terpenuhi' : 'Butuh minimal ' . $b['education']['minEducationLabel'])
                    . '; ' . ($b['education']['majorMatch'] ? 'jurusan sesuai' : 'jurusan kurang umum untuk posisi ini')) ?>
                <?= bagianSkor('Pengalaman', $b['experience'], $b['experience']['relevantYears'] . ' tahun relevan dari ' . $b['experience']['idealYears'] . ' tahun ideal') ?>
                <?php if ($b['certification']): ?>
                    <?= bagianSkor('Sertifikasi', $b['certification'],
                        $r['certifications']['owned'] ? 'Memiliki ' . count($r['certifications']['owned']) . ' sertifikasi relevan' : 'Belum ada sertifikasi relevan') ?>
                <?php endif; ?>
            </div>

            <h4>Skill yang dibutuhkan</h4>
            <ul class="reqs">
                <?php foreach ($r['skills'] as $s): ?>
                    <li class="req st-<?= e($s['status']) ?>">
                        <span class="req-name"><?= e($s['name']) ?><small><?= e($s['category']) ?> - bobot <?= (int) $s['weight'] ?></small></span>
                        <?= meter((int) $s['userLevel'], (int) $s['requiredLevel']) ?>
                        <span class="req-txt"><?= (int) $s['userLevel'] ?>/<?= (int) $s['requiredLevel'] ?></span>
                        <span class="pill <?= e($s['status']) ?>"><?= e(TEKS_STATUS[$s['status']]) ?></span>
                    </li>
                <?php endforeach; ?>
            </ul>

            <div class="two">
                <div>
                    <h4>Yang sudah kuat</h4>
                    <?php if ($r['strengths']): ?>
                        <ul class="plain">
                            <?php foreach ($r['strengths'] as $s): ?>
                                <li><?= e($s['name']) ?><small>Level <?= (int) $s['userLevel'] ?>, dibutuhkan <?= (int) $s['requiredLevel'] ?></small></li>
                            <?php endforeach; ?>
                        </ul>
                    <?php else: ?>
                        <p class="empty">Belum ada skill yang mencapai level yang dibutuhkan.</p>
                    <?php endif; ?>
                </div>
                <div>
                    <h4>Sertifikasi yang disarankan</h4>
                    <?php if ($r['certifications']['missing']): ?>
                        <ul class="plain">
                            <?php foreach ($r['certifications']['missing'] as $c): ?>
                                <li><?= e($c['name']) ?><small><?= e($c['issuer']) ?></small></li>
                            <?php endforeach; ?>
                        </ul>
                    <?php else: ?>
                        <p class="empty">Tidak ada sertifikasi tambahan yang perlu dikejar.</p>
                    <?php endif; ?>
                </div>
            </div>

            <h4>Prioritas belajar</h4>
            <?php $prioritas = array_slice($r['gaps'], 0, 4); ?>
            <?php if (!$prioritas): ?>
                <p class="empty">Semua skill utama sudah memenuhi standar. Fokuslah pada pengalaman dan portofolio.</p>
            <?php endif; ?>
            <?php foreach ($prioritas as $g): ?>
                <div class="learn">
                    <b><?= e($g['name']) ?></b>
                    <span class="lv">Level <?= (int) $g['userLevel'] ?> menuju <?= (int) $g['requiredLevel'] ?></span>
                    <?php if (!empty($g['learningTip'])): ?><p><?= e($g['learningTip']) ?></p><?php endif; ?>
                    <?php if (amanUrl($g['learningUrl'] ?? null)): ?>
                        <p><a href="<?= e(amanUrl($g['learningUrl'])) ?>" target="_blank" rel="noopener noreferrer">Buka materi belajar</a></p>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </details>
<?php endforeach; ?>
</div>
<?php pageFooter(); ?>
