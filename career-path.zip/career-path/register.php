<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/layout.php';

if ($sudah = currentUser()) {
    header('Location: ' . homeFor($sudah['role'] ?? ''));
    exit;
}

$errors = [];
$name = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();

    $name     = trim($_POST['name'] ?? '');
    $email    = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';

    if (mb_strlen($name) < 2 || mb_strlen($name) > 100) {
        $errors[] = 'Nama harus 2 sampai 100 karakter.';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 150) {
        $errors[] = 'Format email tidak valid.';
    }
    if (strlen($password) < 8) {
        $errors[] = 'Kata sandi minimal 8 karakter.';
    }

    if (!$errors) {
        $pdo = getMysqlConnection();

        $cek = $pdo->prepare('SELECT id FROM users WHERE email = ?');
        $cek->execute([$email]);
        if ($cek->fetch()) {
            $errors[] = 'Email ini sudah terdaftar. Silakan masuk.';
        } else {
            $pdo->beginTransaction();
            try {
                $simpan = $pdo->prepare('INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)');
                $simpan->execute([$name, $email, password_hash($password, PASSWORD_DEFAULT)]);
                $id = (int) $pdo->lastInsertId();

                // setiap pengguna punya satu baris profil kosong
                $pdo->prepare('INSERT INTO profiles (user_id) VALUES (?)')->execute([$id]);
                $pdo->commit();
            } catch (Throwable $err) {
                $pdo->rollBack();
                throw $err;
            }

            loginUser(['id' => $id, 'name' => $name, 'email' => $email, 'role' => 'user']);
            header('Location: dashboard.php');
            exit;
        }
    }
}

pageHeader('Daftar', [], [], 'auth');
?>
<section class="auth-hero">
    <?= bentuk('auth') ?>
    <div class="card narrow">
    <h1>Buat akun</h1>
    <p class="lead">Gratis. Cukup nama, email, dan kata sandi.</p>

    <?php foreach ($errors as $pesan): ?>
        <div class="error"><?= e($pesan) ?></div>
    <?php endforeach; ?>

    <form method="post" novalidate>
        <?= csrfField() ?>
        <label for="name">Nama lengkap</label>
        <input type="text" id="name" name="name" value="<?= e($name) ?>" maxlength="100" required>

        <label for="email">Email</label>
        <input type="email" id="email" name="email" value="<?= e($email) ?>" maxlength="150" required>

        <label for="password">Kata sandi</label>
        <input type="password" id="password" name="password" autocomplete="new-password" required>
        <p class="hint">Minimal 8 karakter.</p>

        <button type="submit">Buat akun</button>
    </form>
    <p class="auth-bawah">Sudah punya akun? <a href="login.php">Masuk</a></p>
    </div>
</section>
<?php pageFooter(); ?>
