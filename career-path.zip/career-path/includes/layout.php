<?php
// Kepala dan kaki halaman yang dipakai bersama.
require_once __DIR__ . '/auth.php';

/** Menyimpan daftar file JavaScript halaman ini, supaya bisa dipasang di kaki halaman. */
function pageScripts(?array $baru = null): array
{
    static $daftar = [];
    if ($baru !== null) {
        $daftar = $baru;
    }
    return $daftar;
}

/** Logo: lingkaran biru dengan jalur naik dan titik magenta di ujungnya. */
function logoMark(int $ukuran = 34): string
{
    return '<svg width="' . $ukuran . '" height="' . $ukuran . '" viewBox="0 0 34 34" aria-hidden="true">'
        . '<circle cx="17" cy="17" r="17" fill="#1b4bd1"/>'
        . '<path d="M9 23 L15 16 L19 20 L25 11" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/>'
        . '<circle cx="25" cy="11" r="3.4" fill="#e5007d"/></svg>';
}

/** Bentuk geometris sebagai hiasan pita biru. $jenis: banner, hero, auth, atau cta. */
function bentuk(string $jenis = 'banner'): string
{
    $atas = 'class="shapes" aria-hidden="true" focusable="false"';
    switch ($jenis) {
        case 'hero':
            return '<svg ' . $atas . ' viewBox="0 0 1440 640" preserveAspectRatio="xMidYMid slice">'
                . '<circle cx="-30" cy="600" r="280" fill="#0f2870"/>'
                . '<path d="M1140 0 A300 300 0 0 0 1440 300 L1440 0 Z" fill="#e5007d"/>'
                . '<path d="M1000 0 A120 120 0 0 0 1120 120 L1120 0 Z" fill="#1b4bd1"/>'
                . '<circle cx="1290" cy="560" r="74" fill="none" stroke="#1b4bd1" stroke-width="40"/>'
                . '</svg>';
        case 'auth':
            return '<svg ' . $atas . ' viewBox="0 0 1440 520" preserveAspectRatio="xMidYMid slice">'
                . '<path d="M0 520 A260 260 0 0 1 260 260 L260 520 Z" fill="#0f2870"/>'
                . '<path d="M1200 0 A240 240 0 0 0 1440 240 L1440 0 Z" fill="#e5007d"/>'
                . '<circle cx="1230" cy="430" r="60" fill="none" stroke="#1b4bd1" stroke-width="34"/>'
                . '<circle cx="190" cy="120" r="26" fill="#1b4bd1"/>'
                . '</svg>';
        case 'cta':
            return '<svg ' . $atas . ' viewBox="0 0 1440 300" preserveAspectRatio="xMidYMid slice">'
                . '<path d="M1240 0 A200 200 0 0 0 1440 200 L1440 0 Z" fill="#e5007d"/>'
                . '<circle cx="-20" cy="300" r="170" fill="#0f2870"/>'
                . '<circle cx="1120" cy="250" r="44" fill="none" stroke="#1b4bd1" stroke-width="26"/>'
                . '</svg>';
        default:
            return '<svg ' . $atas . ' viewBox="0 0 300 150" preserveAspectRatio="xMaxYMid slice">'
                . '<path d="M170 0 A130 130 0 0 0 300 130 L300 0 Z" fill="#e5007d"/>'
                . '<path d="M96 150 A56 56 0 0 1 208 150 Z" fill="#12307c"/>'
                . '<circle cx="246" cy="112" r="20" fill="none" stroke="#1b4bd1" stroke-width="12"/>'
                . '</svg>';
    }
}

/**
 * Pita judul di bagian atas halaman.
 * @param string $aksi HTML tombol (opsional), tampil di sisi kanan
 */
function pageBanner(string $judul, string $sub = '', string $aksi = ''): void
{
    echo '<section class="banner"><div><h1>' . e($judul) . '</h1>';
    if ($sub !== '') {
        echo '<p>' . e($sub) . '</p>';
    }
    echo '</div>';
    if ($aksi !== '') {
        echo '<div class="aksi">' . $aksi . '</div>';
    }
    echo bentuk('banner') . '</section>';
}

/** Menu di bilah atas untuk admin. [file => [label, file yang dianggap aktif...]] */
function menuAdmin(): array
{
    return [
        'admin.php'        => 'Ringkasan',
        'admin_kb.php'     => 'Knowledge base',
        'admin_users.php'  => 'Pengguna',
        'qdrant_index.php' => 'Indeks Qdrant',
    ];
}

/** Menu di bilah atas untuk pengguna biasa. */
function menuPengguna(): array
{
    return [
        'dashboard.php' => 'Beranda',
        'profile.php'   => 'Profil',
        'history.php'   => 'Riwayat',
        'cari.php'      => 'Cari',
    ];
}

/**
 * @param string   $judul     judul halaman
 * @param string[] $css       file CSS tambahan (opsional)
 * @param string[] $js        file JavaScript tambahan (opsional)
 * @param string   $bodyClass kelas untuk tag body: auth atau landing (opsional)
 */
function pageHeader(string $judul, array $css = [], array $js = [], string $bodyClass = ''): void
{
    pageScripts($js);
    $user  = currentUser();
    $admin = $user && ($user['role'] ?? '') === 'admin';
    $file  = basename($_SERVER['SCRIPT_NAME'] ?? '');
    if ($file === 'result.php') {
        $file = 'history.php';   // hasil analisis dianggap bagian dari Riwayat
    }
    ?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($judul) ?> | Career Path</title>
    <link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 34 34'%3E%3Ccircle cx='17' cy='17' r='17' fill='%231b4bd1'/%3E%3Ccircle cx='25' cy='11' r='4' fill='%23e5007d'/%3E%3C/svg%3E">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&amp;display=swap">
    <link rel="stylesheet" href="assets/style.css">
    <?php if ($user && !$admin): ?>
        <link rel="stylesheet" href="assets/chatbot.css">
    <?php endif; ?>
    <?php foreach ($css as $berkas): ?>
        <link rel="stylesheet" href="<?= e($berkas) ?>">
    <?php endforeach; ?>
</head>
<body<?= $bodyClass !== '' ? ' class="' . e($bodyClass) . '"' : '' ?>>
<header class="topbar<?= $admin ? ' is-admin' : '' ?>">
    <div class="topbar-in">
        <a class="brand" href="<?= $user ? e(homeFor($user['role'] ?? '')) : 'index.php' ?>"><?= logoMark() ?>careerpath<?= $admin ? '<span class="badge-admin">Admin</span>' : '' ?></a>
        <?php if ($user): ?>
            <nav class="nav-main" aria-label="Menu utama">
                <?php foreach (($admin ? menuAdmin() : menuPengguna()) as $tujuan => $label): ?>
                    <a href="<?= e($tujuan) ?>"<?= $tujuan === $file ? ' class="on" aria-current="page"' : '' ?>><?= e($label) ?></a>
                <?php endforeach; ?>
            </nav>
            <div class="nav-side">
                <span class="who"><?= e($user['name']) ?></span>
                <form method="post" action="logout.php" class="inline">
                    <?= csrfField() ?>
                    <button type="submit" class="link">Keluar</button>
                </form>
            </div>
        <?php else: ?>
            <nav class="nav-main" aria-label="Menu utama">
                <a href="index.php#cara-kerja">Cara kerja</a>
                <a href="index.php#karier">Karier</a>
                <a href="index.php#teknologi">Teknologi</a>
            </nav>
            <div class="nav-side">
                <a class="btn ghost" href="login.php">Masuk</a>
                <a class="btn" href="register.php">Daftar</a>
            </div>
        <?php endif; ?>
    </div>
</header>
<main>
<?php
}

/** @param bool $lengkap true untuk kaki halaman berkolom (halaman depan) */
function pageFooter(bool $lengkap = false): void
{
    $user  = currentUser();
    $admin = $user && ($user['role'] ?? '') === 'admin';
    ?>
</main>
<?php if ($lengkap): ?>
<footer class="foot">
    <div class="wrap">
        <div class="foot-cols">
            <div>
                <a class="brand" href="index.php"><?= logoMark(30) ?>careerpath</a>
                <p class="tentang">Temukan karier yang paling sesuai dengan skill, pendidikan, dan pengalamanmu.</p>
            </div>
            <div>
                <h4>Untuk pengguna</h4>
                <ul>
                    <li><a href="login.php">Masuk</a></li>
                    <li><a href="register.php">Daftar gratis</a></li>
                    <li><a href="index.php#cara-kerja">Cara kerja</a></li>
                    <li><a href="index.php#karier">Daftar karier</a></li>
                </ul>
            </div>
            <div>
                <h4>Tentang aplikasi</h4>
                <ul>
                    <li><a href="index.php#teknologi">Teknologi</a></li>
                    <li><a href="index.php#karier">Knowledge base</a></li>
                </ul>
            </div>
            <div>
                <h4>Pengelola</h4>
                <ul>
                    <li><a href="login.php">Masuk sebagai admin</a></li>
                </ul>
            </div>
        </div>
        <div class="foot-bawah">
            <span>Proyek mata kuliah Basis Data (PBD)</span>
            <span>Hak cipta &copy; <?= date('Y') ?> Career Path</span>
        </div>
    </div>
</footer>
<?php else: ?>
<footer class="foot-kecil">
    <div class="wrap">
        <span>Career Path - proyek mata kuliah Basis Data (PBD)</span>
        <span>&copy; <?= date('Y') ?></span>
    </div>
</footer>
<?php endif; ?>
<?php if ($user && !$admin): ?>
<div id="chatbot" data-csrf="<?= e(csrfToken()) ?>"></div>
<script src="assets/chatbot.js"></script>
<?php endif; ?>
<?php foreach (pageScripts() as $berkas): ?>
<script src="<?= e($berkas) ?>"></script>
<?php endforeach; ?>
</body>
</html>
<?php
}
