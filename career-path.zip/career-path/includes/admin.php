<?php
// Penjaga halaman admin dan perlengkapan kecil yang dipakai semua halaman admin.

require_once __DIR__ . '/layout.php';

/**
 * Hanya untuk admin. Peran dicek ulang ke database setiap kali,
 * jadi kalau peran seseorang diubah, hasilnya langsung berlaku.
 */
function requireAdmin(PDO $pdo): array
{
    $user = requireLogin();

    $q = $pdo->prepare('SELECT role FROM users WHERE id = ?');
    $q->execute([$user['id']]);
    $peran = $q->fetchColumn();

    $_SESSION['user']['role'] = $peran === false ? 'user' : (string) $peran;

    if ($peran !== 'admin') {
        http_response_code(403);
        pageHeader('Khusus admin');
        ?>
        <div class="card">
            <h1>Halaman ini khusus admin</h1>
            <p>Halaman ini hanya bisa dibuka dengan akun admin.</p>
            <p style="margin-bottom:0"><a class="btn" href="dashboard.php">Kembali ke beranda</a></p>
        </div>
        <?php
        pageFooter();
        exit;
    }

    return $_SESSION['user'];
}

/**
 * Menu admin sekarang ada di bilah atas (lihat menuAdmin() di layout.php).
 * Fungsi ini dibiarkan supaya halaman lama tetap jalan, tapi tidak menampilkan apa-apa.
 */
function adminNav(string $aktif): void
{
}

/** Menyimpan pesan yang akan tampil sekali di halaman berikutnya. $jenis: ok, warn, atau error. */
function flashSet(string $jenis, string $pesan): void
{
    $_SESSION['flash'][] = ['jenis' => $jenis, 'pesan' => $pesan];
}

/** Menampilkan lalu menghapus pesan yang tersimpan. */
function flashShow(): void
{
    foreach ($_SESSION['flash'] ?? [] as $f) {
        $kelas = in_array($f['jenis'], ['ok', 'warn', 'error'], true) ? $f['jenis'] : 'ok';
        echo '<div class="' . $kelas . '">' . e($f['pesan']) . '</div>';
    }
    unset($_SESSION['flash']);
}

/** Daftar pesan kesalahan dalam satu kotak merah. */
function adminErrors(array $daftar): void
{
    if (!$daftar) {
        return;
    }
    echo '<div class="error"><b>Belum bisa disimpan:</b><ul>';
    foreach ($daftar as $pesan) {
        echo '<li>' . e($pesan) . '</li>';
    }
    echo '</ul></div>';
}

/** Pilihan untuk kotak <select>. $opsi: [nilai => label]. */
function adminOpsi(array $opsi, $terpilih): string
{
    $html = '';
    foreach ($opsi as $nilai => $label) {
        $pilih = (string) $nilai === (string) $terpilih ? ' selected' : '';
        $html .= '<option value="' . e((string) $nilai) . '"' . $pilih . '>' . e((string) $label) . '</option>';
    }
    return $html;
}

/** Batang persentase sederhana (memakai kelas .bar dari result.css). */
function adminBatang(float $nilai, float $maks): string
{
    $persen = $maks > 0 ? (int) round($nilai / $maks * 100) : 0;
    $persen = max(0, min(100, $persen));
    return '<div class="bar"><span style="width:' . $persen . '%"></span></div>';
}
