<?php
// Menghubungkan MySQL (profil, riwayat), MongoDB (pengetahuan), dan mesin penghitung.

require_once __DIR__ . '/kb.php';
require_once __DIR__ . '/engine.php';
require_once __DIR__ . '/profile_repo.php';

/**
 * Menjalankan analisis untuk satu pengguna lalu menyimpan hasilnya.
 * @return int|null id analisis, atau null kalau pengguna belum memilih skill.
 */
function runAssessment(PDO $pdo, int $userId): ?int
{
    $profil = loadProfile($pdo, $userId);              // 1. ambil profil dari MySQL
    $kb     = kbKnowledge();                           // 2. ambil pengetahuan dari MongoDB
    $cfg    = kbConfig();

    // buang skill/sertifikasi yang sudah tidak ada di knowledge base
    $kodeSkill = array_column($kb['skills'], 'code');
    $kodeCert  = array_column($kb['certifications'], 'code');
    $profil['skills'] = array_filter($profil['skills'], fn($kode) => in_array($kode, $kodeSkill, true), ARRAY_FILTER_USE_KEY);
    $profil['certs']  = array_values(array_intersect($profil['certs'], $kodeCert));

    if (!$profil['skills'] || !$kb['careers']) {
        return null;
    }

    $hasil = hitungKecocokan($profil, $kb, $cfg);      // 3. hitung (tanpa database)
    $top   = array_slice($hasil, 0, max(1, (int) round($cfg['top_n'])));
    return saveAssessment($pdo, $userId, $profil, $top); // 4. simpan riwayat ke MySQL
}

function saveAssessment(PDO $pdo, int $userId, array $snapshot, array $hasil): int
{
    $json = fn($data) => json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    $pdo->beginTransaction();
    try {
        $pdo->prepare('INSERT INTO assessments (user_id, snapshot) VALUES (?, ?)')->execute([$userId, $json($snapshot)]);
        $id = (int) $pdo->lastInsertId();

        $ins = $pdo->prepare('INSERT INTO assessment_results (assessment_id, rank_no, career_code, career_name, score, label, detail) VALUES (?, ?, ?, ?, ?, ?, ?)');
        foreach ($hasil as $i => $r) {
            $ins->execute([$id, $i + 1, $r['careerCode'], $r['careerName'], $r['score'], $r['label'], $json($r)]);
        }
        $pdo->commit();
        return $id;
    } catch (Throwable $err) {
        $pdo->rollBack();
        throw $err;
    }
}

/** Satu analisis lengkap milik pengguna, atau null. */
function getAssessment(PDO $pdo, int $userId, int $id): ?array
{
    $q = $pdo->prepare('SELECT id, created_at FROM assessments WHERE id = ? AND user_id = ?');
    $q->execute([$id, $userId]);
    $a = $q->fetch(PDO::FETCH_ASSOC);
    if (!$a) {
        return null;
    }
    $q = $pdo->prepare('SELECT rank_no, detail FROM assessment_results WHERE assessment_id = ? ORDER BY rank_no');
    $q->execute([$id]);
    $a['results'] = [];
    foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $r) {
        $a['results'][] = ['rank' => (int) $r['rank_no']] + json_decode($r['detail'], true);
    }
    return $a;
}

/** Riwayat analisis pengguna (terbaru dulu). */
function listAssessments(PDO $pdo, int $userId, int $batas = 50): array
{
    $q = $pdo->prepare(
        'SELECT a.id, a.created_at, r.career_name, r.score, r.label
           FROM assessments a
           LEFT JOIN assessment_results r ON r.assessment_id = a.id AND r.rank_no = 1
          WHERE a.user_id = ? ORDER BY a.id DESC LIMIT ' . (int) $batas
    );
    $q->execute([$userId]);
    return $q->fetchAll(PDO::FETCH_ASSOC);
}
