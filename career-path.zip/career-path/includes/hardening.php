<?php
/**
 * PENGAMANAN DAN PENGATURAN BERSAMA
 * ----------------------------------------------------------------
 * File ini tidak melakukan apa pun saat di-include. Fungsi appBoot() dipanggil
 * dari includes/auth.php, sehingga semua halaman ikut terlindungi.
 *
 * Pengaturan di .env:
 *   APP_ENV      "production" di server publik. Kosong/"development" di komputer sendiri.
 *   TRUST_PROXY  "true" bila aplikasi berada di belakang proxy hosting (Railway, Render, dll.)
 */

/** Membaca pengaturan dari lingkungan server atau dari file .env di folder proyek. */
function appEnv(string $kunci, ?string $bawaan = null): ?string
{
    static $isiFile = null;

    $v = getenv($kunci);
    if ($v !== false && $v !== '') {
        return $v;
    }
    if (!empty($_ENV[$kunci])) {
        return $_ENV[$kunci];
    }
    if ($isiFile === null) {
        $isiFile = [];
        $path = __DIR__ . '/../.env';
        if (is_readable($path)) {
            foreach (file($path, FILE_IGNORE_NEW_LINES) as $baris) {
                $baris = trim($baris);
                if ($baris === '' || $baris[0] === '#' || !str_contains($baris, '=')) {
                    continue;
                }
                [$k, $nilai] = explode('=', $baris, 2);
                $isiFile[trim($k)] = trim(trim($nilai), "\"'");
            }
        }
    }
    return $isiFile[$kunci] ?? $bawaan;
}

function appProduksi(): bool
{
    return strtolower((string) appEnv('APP_ENV', 'development')) === 'production';
}

function appPercayaProxy(): bool
{
    return strtolower((string) appEnv('TRUST_PROXY', 'false')) === 'true';
}

/** Apakah pengunjung memakai HTTPS (termasuk lewat proxy hosting). */
function appHttps(): bool
{
    if (($_SERVER['HTTPS'] ?? '') !== '' && strtolower($_SERVER['HTTPS']) !== 'off') {
        return true;
    }
    return appPercayaProxy() && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https';
}

function appIpKlien(): string
{
    if (appPercayaProxy() && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
        if (filter_var($ip, FILTER_VALIDATE_IP)) {
            return $ip;
        }
    }
    return (string) ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
}

/** Dipanggil sekali per permintaan. */
function appBoot(): void
{
    static $sudah = false;
    if ($sudah || PHP_SAPI === 'cli') {
        return;
    }
    $sudah = true;

    if (appProduksi()) {
        // Di server publik, detail error tidak boleh terlihat pengunjung. Cukup dicatat di log server.
        ini_set('display_errors', '0');
        ini_set('log_errors', '1');
        error_reporting(E_ALL);
        set_exception_handler('appTanganiError');
    }

    if (!headers_sent()) {
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: SAMEORIGIN');
        header('Referrer-Policy: strict-origin-when-cross-origin');
        header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
        if (appHttps()) {
            header('Strict-Transport-Security: max-age=15552000');
        }
    }

    appBatasiPercobaan();
}

/** Penangan error terakhir (hanya mode produksi): catat detailnya, tampilkan pesan umum. */
function appTanganiError(Throwable $e): void
{
    error_log('[app] ' . get_class($e) . ': ' . $e->getMessage() . ' di ' . $e->getFile() . ':' . $e->getLine());
    if (!headers_sent()) {
        http_response_code(500);
    }
    $minta = $_SERVER['HTTP_ACCEPT'] ?? '';
    if (str_contains($minta, 'application/json') || basename($_SERVER['SCRIPT_NAME'] ?? '') === 'chat.php') {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['error' => 'Terjadi kesalahan pada server. Coba lagi sebentar.']);
        return;
    }
    echo '<!doctype html><meta charset="utf-8"><title>Terjadi kesalahan</title>'
        . '<body style="font-family:system-ui;max-width:32rem;margin:15vh auto;padding:0 1rem">'
        . '<h1>Terjadi kesalahan</h1><p>Maaf, ada masalah di server. Coba lagi beberapa saat lagi.</p>'
        . '<p><a href="dashboard.php">Kembali ke beranda</a></p></body>';
}

/* ---------------------------------------------------------------- pembatas percobaan */

/** Halaman yang dibatasi: [maksimal percobaan, dalam berapa detik, nama jenis]. */
const APP_BATAS_AKSES = [
    'login.php'    => [15, 600, 'login'],   // 15 percobaan per 10 menit per alamat IP
    'register.php' => [10, 3600, 'daftar'], // 10 pendaftaran per jam per alamat IP
];

/**
 * Menghambat tebak-tebakan sandi dan pendaftaran massal.
 * Bila tabel atau database bermasalah, pengguna TIDAK diblokir (hanya dicatat di log).
 */
function appBatasiPercobaan(): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        return;
    }
    $skrip = basename($_SERVER['SCRIPT_NAME'] ?? '');
    if (!isset(APP_BATAS_AKSES[$skrip])) {
        return;
    }
    [$maks, $detik, $jenis] = APP_BATAS_AKSES[$skrip];

    try {
        require_once __DIR__ . '/../config/db.php';
        $pdo = getMysqlConnection();
        $pdo->exec(
            'CREATE TABLE IF NOT EXISTS percobaan_akses (
                id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                jenis VARCHAR(20) NOT NULL,
                ip VARCHAR(45) NOT NULL,
                waktu TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                KEY idx_percobaan (jenis, ip, waktu)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
        );
        $ip = appIpKlien();

        $q = $pdo->prepare('SELECT COUNT(*) FROM percobaan_akses WHERE jenis = ? AND ip = ? AND waktu > (NOW() - INTERVAL ' . (int) $detik . ' SECOND)');
        $q->execute([$jenis, $ip]);
        if ((int) $q->fetchColumn() >= $maks) {
            http_response_code(429);
            header('Retry-After: ' . (int) $detik);
            echo '<!doctype html><meta charset="utf-8"><title>Terlalu banyak percobaan</title>'
                . '<body style="font-family:system-ui;max-width:32rem;margin:15vh auto;padding:0 1rem">'
                . '<h1>Terlalu banyak percobaan</h1><p>Demi keamanan, coba lagi dalam ' . (int) ceil($detik / 60) . ' menit.</p></body>';
            exit;
        }
        $pdo->prepare('INSERT INTO percobaan_akses (jenis, ip) VALUES (?, ?)')->execute([$jenis, $ip]);

        if (random_int(1, 50) === 1) { // bersih-bersih catatan lama sesekali
            $pdo->exec('DELETE FROM percobaan_akses WHERE waktu < (NOW() - INTERVAL 1 DAY)');
        }
    } catch (Throwable $e) {
        error_log('[pembatas] ' . $e->getMessage());
    }
}
