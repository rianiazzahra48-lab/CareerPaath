<?php
/**
 * QDRANT UNTUK PENCARIAN MAKNA
 * ----------------------------------------------------------------
 * Qdrant menyimpan "sidik arti" (vektor) dari setiap karier dan skill.
 * Vektor dibuat oleh model gratis di Qdrant Cloud (Cloud Inference),
 * jadi tidak perlu API key tambahan.
 *
 * Pengaturan di file .env (semuanya opsional kecuali dua yang pertama):
 *   QDRANT_URL, QDRANT_API_KEY
 *   QDRANT_COLLECTION   nama koleksi          (bawaan: career_knowledge)
 *   QDRANT_EMBED_MODEL  nama model embedding  (bawaan: intfloat/multilingual-e5-small)
 *   QDRANT_EMBED_DIM    jumlah dimensi model  (bawaan: 384)
 *   QDRANT_SSL_VERIFY   isi "false" hanya jika muncul error sertifikat SSL di XAMPP
 */

require_once __DIR__ . '/kb.php';

/** Membaca pengaturan dari lingkungan atau langsung dari file .env. */
function qkbEnv(string $kunci, ?string $bawaan = null): ?string
{
    static $isiFile = null;

    $v = getenv($kunci);
    if ($v !== false && $v !== '') {
        return $v;
    }
    if (!empty($_ENV[$kunci])) {
        return $_ENV[$kunci];
    }
    if ($isiFile === null) {
        $isiFile = [];
        $path = __DIR__ . '/../.env';
        if (is_readable($path)) {
            foreach (file($path, FILE_IGNORE_NEW_LINES) as $baris) {
                $baris = trim($baris);
                if ($baris === '' || $baris[0] === '#' || !str_contains($baris, '=')) {
                    continue;
                }
                [$k, $nilai] = explode('=', $baris, 2);
                $isiFile[trim($k)] = trim(trim($nilai), "\"'");
            }
        }
    }
    return $isiFile[$kunci] ?? $bawaan;
}

function qkbKoleksi(): string { return qkbEnv('QDRANT_COLLECTION', 'career_knowledge'); }
function qkbModel(): string   { return qkbEnv('QDRANT_EMBED_MODEL', 'intfloat/multilingual-e5-small'); }
function qkbDimensi(): int    { return (int) qkbEnv('QDRANT_EMBED_DIM', '384'); }

/** Satu permintaan ke Qdrant. Hasil: ['status'=>kode HTTP, 'data'=>array, 'raw'=>teks]. */
function qkbRequest(string $method, string $path, ?array $body = null): array
{
    $alamat = rtrim((string) qkbEnv('QDRANT_URL', ''), '/');
    if ($alamat === '') {
        throw new RuntimeException('QDRANT_URL belum diisi di file .env.');
    }

    $header = ['Content-Type: application/json', 'Accept: application/json'];
    if ($kunci = qkbEnv('QDRANT_API_KEY')) {
        $header[] = 'api-key: ' . $kunci;
    }

    $isi = $body !== null ? json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null;
    $tanpaSsl = qkbEnv('QDRANT_SSL_VERIFY', 'true') === 'false';

    if (function_exists('curl_init')) {
        $ch = curl_init($alamat . $path);
        curl_setopt_array($ch, [
            CURLOPT_CUSTOMREQUEST  => $method,
            CURLOPT_HTTPHEADER     => $header,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT        => 60,
        ]);
        if ($tanpaSsl) {
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        }
        if ($isi !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $isi);
        }
        $raw = curl_exec($ch);
        if ($raw === false) {
            $pesan = 'Tidak bisa terhubung ke Qdrant (' . curl_errno($ch) . '): ' . curl_error($ch);
            curl_close($ch);
            throw new RuntimeException($pesan);
        }
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
    } else {
        // Cadangan bila ekstensi cURL tidak aktif
        $opsi = ['http' => [
            'method' => $method, 'header' => implode("\r\n", $header), 'content' => $isi ?? '',
            'ignore_errors' => true, 'timeout' => 60,
        ]];
        if ($tanpaSsl) {
            $opsi['ssl'] = ['verify_peer' => false, 'verify_peer_name' => false];
        }
        $raw = @file_get_contents($alamat . $path, false, stream_context_create($opsi));
        if ($raw === false) {
            throw new RuntimeException('Tidak bisa terhubung ke Qdrant. Periksa QDRANT_URL dan koneksi internet.');
        }
        $status = 0;
        foreach ($http_response_header ?? [] as $baris) {
            if (preg_match('#^HTTP/\S+\s+(\d{3})#', $baris, $m)) {
                $status = (int) $m[1];
            }
        }
    }

    $data = json_decode($raw, true);
    return ['status' => $status, 'data' => is_array($data) ? $data : [], 'raw' => (string) $raw];
}

function qkbBerhasil(array $r): bool
{
    return $r['status'] >= 200 && $r['status'] < 300;
}

function qkbPesanError(array $r): string
{
    $detail = $r['data']['status']['error'] ?? $r['data']['error'] ?? mb_substr($r['raw'], 0, 300);
    return 'Qdrant menjawab ' . $r['status'] . ': ' . (is_string($detail) ? $detail : json_encode($detail));
}

/** Info koleksi (jumlah titik, dan lain-lain), atau null kalau koleksinya belum ada. */
function qkbInfo(): ?array
{
    $r = qkbRequest('GET', '/collections/' . rawurlencode(qkbKoleksi()));
    if ($r['status'] === 404) {
        return null;
    }
    if (!qkbBerhasil($r)) {
        throw new RuntimeException(qkbPesanError($r));
    }
    return $r['data']['result'] ?? [];
}

/** ID titik yang stabil: kode yang sama selalu menghasilkan ID yang sama. */
function qkbId(string $jenis, string $kode): string
{
    $h = md5($jenis . ':' . $kode);
    return substr($h, 0, 8) . '-' . substr($h, 8, 4) . '-' . substr($h, 12, 4) . '-' . substr($h, 16, 4) . '-' . substr($h, 20, 12);
}

/**
 * Menyusun dokumen yang akan dimasukkan ke Qdrant dari knowledge base (MongoDB).
 * Awalan "passage: " adalah aturan model E5 untuk teks yang disimpan.
 */
function qkbSusunDokumen(): array
{
    $skill  = [];
    foreach (kbSkills() as $s) {
        $skill[$s['code']] = $s;
    }
    $karier = kbCareers();

    // skill -> karier mana saja yang membutuhkannya
    $dipakaiOleh = [];
    foreach ($karier as $k) {
        foreach ($k['requirements'] as $r) {
            $dipakaiOleh[$r['skillCode']][] = $k['name'];
        }
    }

    $dokumen = [];
    foreach ($karier as $k) {
        $butuh = $k['requirements'];
        usort($butuh, fn($a, $b) => $b['weight'] <=> $a['weight']);
        $namaSkill = [];
        foreach ($butuh as $r) {
            if (isset($skill[$r['skillCode']])) {
                $namaSkill[] = $skill[$r['skillCode']]['name'];
            }
        }
        $teks = $k['name'] . '. ' . $k['description']
            . ' Skill yang dibutuhkan: ' . implode(', ', $namaSkill) . '.'
            . ' Pendidikan minimal: ' . (NAMA_JENJANG_KB[$k['minEducation']] ?? '') . '.';
        $dokumen[] = [
            'id'      => qkbId('career', $k['code']),
            'text'    => 'passage: ' . mb_substr($teks, 0, 1500),
            'payload' => ['type' => 'career', 'code' => $k['code'], 'name' => $k['name'], 'description' => $k['description']],
        ];
    }

    foreach ($skill as $kode => $s) {
        $teks = $s['name'] . '. Kategori: ' . $s['category'] . '.'
            . (!empty($s['learningTip']) ? ' Cara belajar: ' . $s['learningTip'] : '')
            . (!empty($dipakaiOleh[$kode]) ? ' Dibutuhkan untuk: ' . implode(', ', array_unique($dipakaiOleh[$kode])) . '.' : '');
        $dokumen[] = [
            'id'      => qkbId('skill', $kode),
            'text'    => 'passage: ' . mb_substr($teks, 0, 1500),
            'payload' => ['type' => 'skill', 'code' => $kode, 'name' => $s['name'], 'category' => $s['category'],
                          'tip' => $s['learningTip'] ?? null, 'careers' => array_values(array_unique($dipakaiOleh[$kode] ?? []))],
        ];
    }
    return $dokumen;
}

const NAMA_JENJANG_KB = [1 => 'SMA/SMK', 2 => 'Diploma (D3)', 3 => 'Sarjana (S1/D4)', 4 => 'Magister (S2)', 5 => 'Doktor (S3)'];

/** Menghapus koleksi lama (kalau ada), membuat ulang, lalu mengisinya. Mengembalikan jumlah titik. */
function qkbBangunUlang(): int
{
    $nama = rawurlencode(qkbKoleksi());
    $dokumen = qkbSusunDokumen();
    if (!$dokumen) {
        throw new RuntimeException('Knowledge base di MongoDB kosong. Tidak ada yang bisa dimasukkan.');
    }

    if (qkbInfo() !== null) {
        $r = qkbRequest('DELETE', "/collections/$nama");
        if (!qkbBerhasil($r)) {
            throw new RuntimeException('Gagal menghapus koleksi lama. ' . qkbPesanError($r));
        }
    }

    $r = qkbRequest('PUT', "/collections/$nama", ['vectors' => ['size' => qkbDimensi(), 'distance' => 'Cosine']]);
    if (!qkbBerhasil($r)) {
        throw new RuntimeException('Gagal membuat koleksi. ' . qkbPesanError($r));
    }

    // indeks pada "type" agar penyaringan (hanya karier / hanya skill) diizinkan
    $r = qkbRequest('PUT', "/collections/$nama/index?wait=true", ['field_name' => 'type', 'field_schema' => 'keyword']);
    if (!qkbBerhasil($r)) {
        throw new RuntimeException('Gagal membuat indeks. ' . qkbPesanError($r));
    }

    foreach (array_chunk($dokumen, 16) as $paket) {
        $titik = array_map(fn($d) => [
            'id'      => $d['id'],
            'vector'  => ['text' => $d['text'], 'model' => qkbModel()],  // Qdrant Cloud membuat vektornya
            'payload' => $d['payload'],
        ], $paket);
        $r = qkbRequest('PUT', "/collections/$nama/points?wait=true", ['points' => $titik]);
        if (!qkbBerhasil($r)) {
            throw new RuntimeException('Gagal memasukkan data. ' . qkbPesanError($r));
        }
    }
    return count($dokumen);
}

/**
 * Mencari berdasarkan arti.
 * @param string|null $jenis 'career' atau 'skill' untuk membatasi hasil
 * @return array daftar ['score'=>float, 'payload'=>array]
 */
function qkbCari(string $pertanyaan, int $batas = 5, ?string $jenis = null): array
{
    $badan = [
        'query'        => ['text' => 'query: ' . $pertanyaan, 'model' => qkbModel()],
        'limit'        => $batas,
        'with_payload' => true,
    ];
    if ($jenis !== null) {
        $badan['filter'] = ['must' => [['key' => 'type', 'match' => ['value' => $jenis]]]];
    }
    $r = qkbRequest('POST', '/collections/' . rawurlencode(qkbKoleksi()) . '/points/query', $badan);
    if (!qkbBerhasil($r)) {
        throw new RuntimeException(qkbPesanError($r));
    }
    $hasil = [];
    foreach ($r['data']['result']['points'] ?? [] as $t) {
        $hasil[] = ['score' => (float) ($t['score'] ?? 0), 'payload' => $t['payload'] ?? []];
    }
    return $hasil;
}
