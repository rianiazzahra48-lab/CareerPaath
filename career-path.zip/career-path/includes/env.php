<?php
function loadEnv(string $path): void
{
    if (!file_exists($path)) {
        die("File .env tidak ditemukan di: $path");
    }
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (str_starts_with(trim($line), '#')) continue; // lewati komentar
        [$key, $value] = array_pad(explode('=', $line, 2), 2, '');
        putenv(trim($key) . '=' . trim($value));
    }
}

// Muat .env dari root project (2 folder di atas includes/)
loadEnv(__DIR__ . '/../.env');