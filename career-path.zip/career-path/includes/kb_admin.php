<?php
/**
 * MENGUBAH KNOWLEDGE BASE DI MONGODB (untuk halaman admin)
 * ----------------------------------------------------------------
 * Halaman biasa hanya MEMBACA pengetahuan lewat includes/kb.php.
 * File ini menambah kemampuan MENULIS (tambah, ubah, hapus) untuk admin,
 * memakai pustaka resmi MongoDB untuk PHP (folder vendor/) dan MONGO_URI dari .env.
 *
 * Nama database diambil dari MONGO_URI (bagian setelah tanda / terakhir).
 * Kalau mau memakai nama lain, isi MONGO_DB di .env.
 */

require_once __DIR__ . '/qdrant_kb.php';   // qkbEnv(), qkbBangunUlang(), kbSkills(), kbCareers(), NAMA_JENJANG_KB

const KA_LEVEL = [1 => 'Mengenal', 2 => 'Dasar', 3 => 'Menengah', 4 => 'Mahir', 5 => 'Ahli'];

/* ------------------------------------------------------------------ */
/* Koneksi dan pembacaan                                               */
/* ------------------------------------------------------------------ */

/** Nama database MongoDB yang dipakai admin. */
function kaNamaDb(): string
{
    $nama = trim((string) qkbEnv('MONGO_DB', ''));
    if ($nama !== '') {
        return $nama;
    }
    $uri = (string) qkbEnv('MONGO_URI', '');
    if (preg_match('#^mongodb(?:\+srv)?://[^/]+/([^/?]+)#', $uri, $m)) {
        return urldecode($m[1]);
    }
    return 'careerpath_kb';
}

/** Koneksi ke database (dibuat sekali per permintaan). */
function kaDb()
{
    static $db = null;
    if ($db !== null) {
        return $db;
    }

    $autoload = __DIR__ . '/../vendor/autoload.php';
    if (!is_readable($autoload)) {
        throw new RuntimeException('Folder vendor/ tidak ditemukan. Jalankan "composer install" di folder project.');
    }
    if (!extension_loaded('mongodb')) {
        throw new RuntimeException('Ekstensi MongoDB untuk PHP belum aktif. Buka php.ini, tambahkan baris extension=mongodb, lalu restart Apache.');
    }
    require_once $autoload;

    $uri = (string) qkbEnv('MONGO_URI', '');
    if ($uri === '') {
        throw new RuntimeException('MONGO_URI belum diisi di file .env.');
    }

    $klien = new MongoDB\Client(
        $uri,
        ['serverSelectionTimeoutMS' => 8000, 'connectTimeoutMS' => 8000],
        ['typeMap' => ['root' => 'array', 'document' => 'array', 'array' => 'array']]
    );
    return $db = $klien->selectDatabase(kaNamaDb());
}

function kaKoleksi(string $nama)
{
    return kaDb()->selectCollection($nama);
}

/** Mengubah dokumen MongoDB menjadi array biasa. */
function kaNormal($dok): array
{
    if (is_array($dok)) {
        return $dok;
    }
    $a = json_decode(json_encode($dok), true);
    return is_array($a) ? $a : [];
}

/** Semua dokumen di satu koleksi. */
function kaSemua(string $koleksi): array
{
    $hasil = [];
    foreach (kaKoleksi($koleksi)->find([], ['sort' => ['_id' => 1]]) as $dok) {
        $hasil[] = kaNormal($dok);
    }
    return $hasil;
}

/** Satu dokumen berdasarkan kode (_id), atau null. */
function kaSatu(string $koleksi, string $kode): ?array
{
    $dok = kaKoleksi($koleksi)->findOne(['_id' => $kode]);
    return $dok === null ? null : kaNormal($dok);
}

function kaJumlah(string $koleksi): int
{
    return (int) kaKoleksi($koleksi)->countDocuments([]);
}

/**
 * Membandingkan data yang dibaca admin dengan data yang dibaca aplikasi (includes/kb.php).
 * Kalau berbeda, berarti keduanya membaca database yang berbeda.
 * @return string|null pesan peringatan, atau null kalau sama
 */
function kaCekSinkron(): ?string
{
    try {
        $beda = [];
        if (kaJumlah('careers') !== count(kbCareers())) {
            $beda[] = 'karier';
        }
        if (kaJumlah('skills') !== count(kbSkills())) {
            $beda[] = 'skill';
        }
        if (kaJumlah('certifications') !== count(kbCertifications())) {
            $beda[] = 'sertifikasi';
        }
        if ($beda) {
            return 'Jumlah ' . implode(', ', $beda) . ' yang dilihat admin (database "' . kaNamaDb()
                . '") berbeda dengan yang dibaca aplikasi. Periksa nama database di includes/mongo.php dan di MONGO_URI.';
        }
    } catch (Throwable $err) {
        return 'Tidak bisa membandingkan data admin dengan data aplikasi: ' . $err->getMessage();
    }
    return null;
}

/** Mengisi ulang indeks Qdrant. Hasil: null kalau berhasil, atau pesan kesalahan. */
function kaIsiUlangQdrant(): ?string
{
    try {
        qkbBangunUlang();
        return null;
    } catch (Throwable $err) {
        return $err->getMessage();
    }
}

/* ------------------------------------------------------------------ */
/* Pembantu kecil                                                      */
/* ------------------------------------------------------------------ */

function kaKodeValid(string $kode): bool
{
    return (bool) preg_match('/^[a-z0-9][a-z0-9_-]{1,39}$/', $kode);
}

function kaTeks($nilai, int $maks): string
{
    return mb_substr(trim((string) $nilai), 0, $maks);
}

function kaAngka($nilai): float
{
    return (float) str_replace(',', '.', trim((string) $nilai));
}

/** Teks banyak baris menjadi daftar (satu item per baris, tanpa yang kosong atau ganda). */
function kaBaris($teks, int $maksItem = 30): array
{
    $daftar = [];
    foreach (preg_split('/\R/u', (string) $teks) ?: [] as $baris) {
        $baris = mb_substr(trim($baris), 0, 60);
        if ($baris !== '' && !in_array($baris, $daftar, true)) {
            $daftar[] = $baris;
        }
    }
    return array_slice($daftar, 0, $maksItem);
}

/* ------------------------------------------------------------------ */
/* SKILL                                                               */
/* ------------------------------------------------------------------ */

function kaBacaFormSkill(array $in): array
{
    return [
        'code'        => kaTeks($in['code'] ?? '', 40),
        'name'        => kaTeks($in['name'] ?? '', 100),
        'category'    => kaTeks($in['category'] ?? '', 60),
        'learningTip' => kaTeks($in['learningTip'] ?? '', 500),
        'learningUrl' => kaTeks($in['learningUrl'] ?? '', 300),
    ];
}

/** @return string[] daftar kesalahan (kosong berarti berhasil disimpan) */
function kaSimpanSkill(array $f, bool $baru): array
{
    $err = [];
    if ($baru && !kaKodeValid($f['code'])) {
        $err[] = 'Kode hanya boleh huruf kecil, angka, tanda - dan _ (2 sampai 40 karakter), misalnya "figma".';
    }
    if ($f['name'] === '') {
        $err[] = 'Nama skill wajib diisi.';
    }
    if ($f['learningUrl'] !== '' && !preg_match('#^https?://#i', $f['learningUrl'])) {
        $err[] = 'Tautan belajar harus diawali http:// atau https://.';
    }
    if ($err) {
        return $err;
    }

    $lama = kaSatu('skills', $f['code']);
    if ($baru && $lama) {
        return ['Kode "' . $f['code'] . '" sudah dipakai skill lain.'];
    }
    if (!$baru && !$lama) {
        return ['Skill tidak ditemukan. Mungkin sudah dihapus.'];
    }

    $dok = $lama ?? [];
    $dok['_id']      = $f['code'];
    $dok['name']     = $f['name'];
    $dok['category'] = $f['category'] !== '' ? $f['category'] : 'Lainnya';
    foreach (['learningTip', 'learningUrl'] as $kunci) {
        if ($f[$kunci] !== '') {
            $dok[$kunci] = $f[$kunci];
        } else {
            unset($dok[$kunci]);
        }
    }
    kaKoleksi('skills')->replaceOne(['_id' => $f['code']], $dok, ['upsert' => true]);
    return [];
}

/* ------------------------------------------------------------------ */
/* SERTIFIKASI                                                         */
/* ------------------------------------------------------------------ */

function kaBacaFormCert(array $in): array
{
    return [
        'code'   => kaTeks($in['code'] ?? '', 40),
        'name'   => kaTeks($in['name'] ?? '', 150),
        'issuer' => kaTeks($in['issuer'] ?? '', 100),
    ];
}

function kaSimpanCert(array $f, bool $baru): array
{
    $err = [];
    if ($baru && !kaKodeValid($f['code'])) {
        $err[] = 'Kode hanya boleh huruf kecil, angka, tanda - dan _ (2 sampai 40 karakter), misalnya "psm1".';
    }
    if ($f['name'] === '') {
        $err[] = 'Nama sertifikasi wajib diisi.';
    }
    if ($err) {
        return $err;
    }

    $lama = kaSatu('certifications', $f['code']);
    if ($baru && $lama) {
        return ['Kode "' . $f['code'] . '" sudah dipakai sertifikasi lain.'];
    }
    if (!$baru && !$lama) {
        return ['Sertifikasi tidak ditemukan. Mungkin sudah dihapus.'];
    }

    $dok = $lama ?? [];
    $dok['_id']    = $f['code'];
    $dok['name']   = $f['name'];
    $dok['issuer'] = $f['issuer'];
    kaKoleksi('certifications')->replaceOne(['_id' => $f['code']], $dok, ['upsert' => true]);
    return [];
}

/* ------------------------------------------------------------------ */
/* KARIER                                                              */
/* ------------------------------------------------------------------ */

/** Membaca formulir karier menjadi dokumen. Hanya skill/sertifikasi yang ada di KB yang dipakai. */
function kaBacaFormKarier(array $in, array $semuaSkill, array $semuaCert): array
{
    $syarat = [];
    foreach ($semuaSkill as $s) {
        $kode  = (string) $s['_id'];
        $level = (int) ($in['req_level'][$kode] ?? 0);
        if ($level >= 1 && $level <= 5) {
            $bobot = (int) ($in['req_weight'][$kode] ?? 3);
            $syarat[] = ['skillCode' => $kode, 'requiredLevel' => $level, 'weight' => max(1, min(10, $bobot))];
        }
    }
    usort($syarat, fn($a, $b) => $b['weight'] <=> $a['weight'] ?: strcmp($a['skillCode'], $b['skillCode']));

    $sertif = [];
    foreach ($semuaCert as $c) {
        $kode = (string) $c['_id'];
        if (!empty($in['cert_use'][$kode])) {
            $bobot = (int) ($in['cert_bonus'][$kode] ?? 2);
            $sertif[] = ['certCode' => $kode, 'bonusWeight' => max(1, min(10, $bobot))];
        }
    }

    $edu = (int) ($in['minEducation'] ?? 3);
    return [
        'code'                 => kaTeks($in['code'] ?? '', 40),
        'name'                 => kaTeks($in['name'] ?? '', 100),
        'description'          => kaTeks($in['description'] ?? '', 1000),
        'minEducation'         => ($edu >= 1 && $edu <= 5) ? $edu : 3,
        'preferredMajors'      => kaBaris($in['preferredMajors'] ?? ''),
        'experienceKeywords'   => kaBaris($in['experienceKeywords'] ?? ''),
        'idealExperienceYears' => round(max(0, min(30, kaAngka($in['idealExperienceYears'] ?? 0))), 1),
        'requirements'         => $syarat,
        'certifications'       => $sertif,
    ];
}

function kaSimpanKarier(array $f, bool $baru): array
{
    $err = [];
    if ($baru && !kaKodeValid($f['code'])) {
        $err[] = 'Kode hanya boleh huruf kecil, angka, tanda - dan _ (2 sampai 40 karakter), misalnya "data-analyst".';
    }
    if ($f['name'] === '') {
        $err[] = 'Nama karier wajib diisi.';
    }
    if ($f['description'] === '') {
        $err[] = 'Deskripsi singkat wajib diisi.';
    }
    if (!$f['requirements']) {
        $err[] = 'Pilih minimal satu skill yang dibutuhkan (atur "Level dibutuhkan" di tabel skill).';
    }
    if ($err) {
        return $err;
    }

    $lama = kaSatu('careers', $f['code']);
    if ($baru && $lama) {
        return ['Kode "' . $f['code'] . '" sudah dipakai karier lain.'];
    }
    if (!$baru && !$lama) {
        return ['Karier tidak ditemukan. Mungkin sudah dihapus.'];
    }

    $dok = $lama ?? [];
    $dok['_id']                  = $f['code'];
    $dok['name']                 = $f['name'];
    $dok['description']          = $f['description'];
    $dok['minEducation']         = $f['minEducation'];
    $dok['preferredMajors']      = array_values($f['preferredMajors']);
    $dok['experienceKeywords']   = array_values($f['experienceKeywords']);
    $dok['idealExperienceYears'] = $f['idealExperienceYears'];
    $dok['requirements']         = array_values($f['requirements']);
    $dok['certifications']       = array_values($f['certifications']);
    kaKoleksi('careers')->replaceOne(['_id' => $f['code']], $dok, ['upsert' => true]);
    return [];
}

/* ------------------------------------------------------------------ */
/* HAPUS                                                               */
/* ------------------------------------------------------------------ */

/**
 * Menghapus satu dokumen. Skill atau sertifikasi yang masih dipakai karier tidak boleh dihapus.
 * @return string[] kesalahan (kosong berarti terhapus)
 */
function kaHapus(string $koleksi, string $kode): array
{
    if (!in_array($koleksi, ['careers', 'skills', 'certifications'], true)) {
        return ['Koleksi tidak dikenal.'];
    }
    if (kaSatu($koleksi, $kode) === null) {
        return ['Data tidak ditemukan. Mungkin sudah dihapus.'];
    }

    if ($koleksi !== 'careers') {
        $pemakai = [];
        foreach (kaSemua('careers') as $k) {
            $daftar = $koleksi === 'skills' ? (array) ($k['requirements'] ?? []) : (array) ($k['certifications'] ?? []);
            $kunci  = $koleksi === 'skills' ? 'skillCode' : 'certCode';
            foreach ($daftar as $r) {
                if ((string) ($r[$kunci] ?? '') === $kode) {
                    $pemakai[] = (string) ($k['name'] ?? $k['_id']);
                    break;
                }
            }
        }
        if ($pemakai) {
            return ['Tidak bisa dihapus karena masih dipakai karier: ' . implode(', ', $pemakai) . '. Lepaskan dulu dari karier tersebut.'];
        }
    }

    kaKoleksi($koleksi)->deleteOne(['_id' => $kode]);
    return [];
}

/* ------------------------------------------------------------------ */
/* BOBOT PENILAIAN (scoring_config)                                    */
/* ------------------------------------------------------------------ */

const KA_KUNCI_BOBOT = ['weight_skill', 'weight_education', 'weight_experience', 'weight_certification'];
const KA_KUNCI_AMBANG = ['threshold_high', 'threshold_medium', 'threshold_low'];

/** Bobot dan ambang yang tersimpan di MongoDB, dilengkapi nilai bawaan untuk yang belum ada. */
function kaConfigSekarang(): array
{
    $nilai = [
        'weight_skill' => 0.60, 'weight_education' => 0.15, 'weight_experience' => 0.15, 'weight_certification' => 0.10,
        'threshold_high' => 75.0, 'threshold_medium' => 55.0, 'threshold_low' => 35.0, 'top_n' => 5,
    ];
    $dok = kaSemua('scoring_config')[0] ?? [];
    foreach ($nilai as $kunci => $awal) {
        if (isset($dok[$kunci]) && is_numeric($dok[$kunci])) {
            $nilai[$kunci] = $kunci === 'top_n' ? (int) $dok[$kunci] : (float) $dok[$kunci];
        }
    }
    return $nilai;
}

/** Membaca formulir bobot dan ambang penilaian. */
function kaBacaFormConfig(array $in): array
{
    $f = [];
    foreach (array_merge(KA_KUNCI_BOBOT, KA_KUNCI_AMBANG) as $kunci) {
        $f[$kunci] = kaAngka($in[$kunci] ?? 0);
    }
    $f['top_n'] = (int) ($in['top_n'] ?? 5);
    return $f;
}

function kaSimpanConfig(array $f): array
{
    $err = [];
    foreach (KA_KUNCI_BOBOT as $kunci) {
        if ($f[$kunci] < 0 || $f[$kunci] > 1) {
            $err[] = 'Bobot harus antara 0 dan 1 (contoh 0.6).';
            break;
        }
    }
    if (array_sum(array_intersect_key($f, array_flip(KA_KUNCI_BOBOT))) <= 0) {
        $err[] = 'Minimal satu bobot harus lebih dari 0.';
    }
    foreach (KA_KUNCI_AMBANG as $kunci) {
        if ($f[$kunci] < 0 || $f[$kunci] > 100) {
            $err[] = 'Ambang skor harus antara 0 dan 100.';
            break;
        }
    }
    if (!($f['threshold_high'] > $f['threshold_medium'] && $f['threshold_medium'] > $f['threshold_low'])) {
        $err[] = 'Urutan ambang harus: tinggi lebih besar dari sedang, dan sedang lebih besar dari rendah.';
    }
    if ($f['top_n'] < 1 || $f['top_n'] > 20) {
        $err[] = 'Jumlah rekomendasi harus antara 1 dan 20.';
    }
    if ($err) {
        return $err;
    }

    $nilai = $f;
    $nilai['top_n'] = (int) $f['top_n'];

    $lama = kaSemua('scoring_config')[0] ?? null;
    if ($lama !== null && isset($lama['_id'])) {
        kaKoleksi('scoring_config')->updateOne(['_id' => $lama['_id']], ['$set' => $nilai]);
    } else {
        kaKoleksi('scoring_config')->insertOne(['_id' => 'default'] + $nilai);
    }
    return [];
}
