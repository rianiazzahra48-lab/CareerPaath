<?php
require_once __DIR__ . '/env.php';

function qdrantRequest(string $method, string $path, ?array $body = null): array
{
    $url = rtrim(getenv('QDRANT_URL'), '/') . $path;

    $ch = curl_init($url);
    $headers = [
        'Content-Type: application/json',
        'api-key: ' . getenv('QDRANT_API_KEY'),
    ];
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => $method,
        CURLOPT_HTTPHEADER     => $headers,
    ]);
    if ($body !== null) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
    }
    $response = curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);

    if ($error) die("Koneksi Qdrant gagal: $error");
    return json_decode($response, true);
}

function qdrantCreateCollection(string $name, int $vectorSize): array
{
    return qdrantRequest('PUT', "/collections/$name", [
        'vectors' => ['size' => $vectorSize, 'distance' => 'Cosine'],
    ]);
}

function qdrantUpsertPoints(string $collection, array $points): array
{
    return qdrantRequest('PUT', "/collections/$collection/points", [
        'points' => $points,
    ]);
}

function qdrantSearch(string $collection, array $vector, int $limit = 5): array
{
    $result = qdrantRequest('POST', "/collections/$collection/points/search", [
        'vector' => $vector,
        'limit'  => $limit,
    ]);
    return $result['result'] ?? [];
}