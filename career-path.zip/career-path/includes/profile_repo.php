<?php
// Membaca dan menyimpan profil pengguna di MySQL.

/** Mengambil seluruh profil pengguna dari MySQL. */
function loadProfile(PDO $pdo, int $userId): array
{
    $q = $pdo->prepare('SELECT education_level, major, headline FROM profiles WHERE user_id = ?');
    $q->execute([$userId]);
    $p = $q->fetch(PDO::FETCH_ASSOC) ?: ['education_level' => 3, 'major' => '', 'headline' => ''];

    $q = $pdo->prepare('SELECT skill_code, level FROM user_skills WHERE user_id = ?');
    $q->execute([$userId]);
    $skills = [];
    foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $r) {
        $skills[$r['skill_code']] = (int) $r['level'];
    }

    $q = $pdo->prepare('SELECT cert_code FROM user_certifications WHERE user_id = ?');
    $q->execute([$userId]);
    $certs = $q->fetchAll(PDO::FETCH_COLUMN);

    $q = $pdo->prepare('SELECT title, company, years, description FROM user_experiences WHERE user_id = ? ORDER BY id');
    $q->execute([$userId]);
    $exp = $q->fetchAll(PDO::FETCH_ASSOC);

    return [
        'education_level' => (int) $p['education_level'],
        'major'           => $p['major'],
        'headline'        => $p['headline'],
        'skills'          => $skills,
        'certs'           => $certs,
        'experiences'     => $exp,
    ];
}

/**
 * Membaca isi formulir profil lalu membersihkannya.
 * Skill/sertifikasi yang tidak ada di knowledge base (MongoDB) dibuang.
 */
function readProfileForm(array $post, array $kbSkills, array $kbCerts): array
{
    $kodeSkill = array_column($kbSkills, 'code');
    $kodeCert  = array_column($kbCerts, 'code');

    $edu = (int) ($post['education_level'] ?? 3);
    if ($edu < 1 || $edu > 5) {
        $edu = 3;
    }

    $skills = [];
    foreach ((array) ($post['skill'] ?? []) as $kode => $level) {
        $level = (int) $level;
        if ($level >= 1 && $level <= 5 && in_array((string) $kode, $kodeSkill, true)) {
            $skills[(string) $kode] = $level;
        }
    }

    $certs = [];
    foreach ((array) ($post['cert'] ?? []) as $kode) {
        if (in_array((string) $kode, $kodeCert, true)) {
            $certs[(string) $kode] = (string) $kode;
        }
    }

    $exp = [];
    $judul = (array) ($post['exp_title'] ?? []);
    foreach ($judul as $i => $t) {
        $t = trim((string) $t);
        if ($t === '' || count($exp) >= 20) {
            continue;
        }
        $tahun = (float) str_replace(',', '.', (string) ($post['exp_years'][$i] ?? 0));
        $exp[] = [
            'title'       => mb_substr($t, 0, 150),
            'company'     => mb_substr(trim((string) ($post['exp_company'][$i] ?? '')), 0, 150),
            'years'       => round(max(0, min(60, $tahun)), 1),
            'description' => mb_substr(trim((string) ($post['exp_desc'][$i] ?? '')), 0, 2000),
        ];
    }

    return [
        'education_level' => $edu,
        'major'           => mb_substr(trim((string) ($post['major'] ?? '')), 0, 120),
        'headline'        => mb_substr(trim((string) ($post['headline'] ?? '')), 0, 200),
        'skills'          => $skills,
        'certs'           => array_values($certs),
        'experiences'     => $exp,
    ];
}

/** Menyimpan profil. Semua perubahan berhasil bersama, atau batal bersama. */
function saveProfile(PDO $pdo, int $userId, array $d): void
{
    $pdo->beginTransaction();
    try {
        $pdo->prepare(
            'INSERT INTO profiles (user_id, education_level, major, headline) VALUES (?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE education_level = VALUES(education_level), major = VALUES(major), headline = VALUES(headline)'
        )->execute([$userId, $d['education_level'], $d['major'], $d['headline']]);

        $pdo->prepare('DELETE FROM user_skills WHERE user_id = ?')->execute([$userId]);
        $ins = $pdo->prepare('INSERT INTO user_skills (user_id, skill_code, level) VALUES (?, ?, ?)');
        foreach ($d['skills'] as $kode => $level) {
            $ins->execute([$userId, $kode, $level]);
        }

        $pdo->prepare('DELETE FROM user_certifications WHERE user_id = ?')->execute([$userId]);
        $ins = $pdo->prepare('INSERT INTO user_certifications (user_id, cert_code) VALUES (?, ?)');
        foreach ($d['certs'] as $kode) {
            $ins->execute([$userId, $kode]);
        }

        $pdo->prepare('DELETE FROM user_experiences WHERE user_id = ?')->execute([$userId]);
        $ins = $pdo->prepare('INSERT INTO user_experiences (user_id, title, company, years, description) VALUES (?, ?, ?, ?, ?)');
        foreach ($d['experiences'] as $e) {
            $ins->execute([$userId, $e['title'], $e['company'], $e['years'], $e['description']]);
        }

        $pdo->commit();
    } catch (Throwable $err) {
        $pdo->rollBack();
        throw $err;
    }
}
