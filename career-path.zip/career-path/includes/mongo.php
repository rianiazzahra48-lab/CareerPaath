<?php
require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/env.php';

function getMongoDatabase(): MongoDB\Database
{
    static $db = null;
    if ($db === null) {
        $uri = getenv('MONGO_URI');
        if (!$uri) {
            throw new RuntimeException('MONGO_URI tidak ditemukan di .env');
        }
        $client = new MongoDB\Client($uri);
        $db = $client->selectDatabase('careerpath_kb');
    }
    return $db;
}

function mongoFindMany(string $collection, array $filter = []): array
{
    $cursor = getMongoDatabase()
        ->selectCollection($collection)
        ->find($filter);
    return iterator_to_array($cursor, false);
}

function mongoInsertOne(string $collection, array $document): array
{
    $result = getMongoDatabase()
        ->selectCollection($collection)
        ->insertOne($document);

    return [
        'insertedId' => (string) $result->getInsertedId(),
        'acknowledged' => $result->isAcknowledged(),
    ];
}