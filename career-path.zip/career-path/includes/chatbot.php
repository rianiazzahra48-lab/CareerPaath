<?php
/**
 * CHATBOT A: ASISTEN BERBASIS PENGETAHUAN (tanpa AI penulis)
 * ----------------------------------------------------------------
 * Semua jawaban disusun dari data nyata, tidak ada karangan:
 *   - MongoDB : karier, skill, sertifikasi, bobot
 *   - MySQL   : profil dan skill milik pengguna yang sedang bertanya
 *   - Qdrant  : pencarian berdasarkan arti, untuk pertanyaan bebas
 *   - Engine  : menghitung kecocokan dan skill gap saat itu juga
 *
 * Cara kerja: (1) kenali maksud pertanyaan lewat kata kunci, (2) kenali karier
 * atau skill yang disebut, (3) susun jawaban dari data. Kalau tidak dikenali,
 * pencarian arti di Qdrant dipakai sebagai cadangan.
 *
 * Setiap jawaban berbentuk ['blocks' => [...], 'suggest' => [...]].
 * Jenis blok: text, list, link.
 */

require_once __DIR__ . '/kb.php';
require_once __DIR__ . '/engine.php';
require_once __DIR__ . '/profile_repo.php';
require_once __DIR__ . '/assessment.php';
require_once __DIR__ . '/qdrant_kb.php';

/** Nama lain yang sering dipakai orang untuk tiap karier (kata utuh, tanpa huruf besar). */
const BOT_ALIAS_KARIER = [
    'ui_ux_designer'         => ['ui', 'ux', 'desainer', 'designer'],
    'system_analyst'         => ['analis sistem'],
    'data_analyst'           => ['analis data'],
    'data_scientist'         => ['data science', 'ilmuwan data'],
    'web_developer'          => ['pengembang web', 'web dev'],
    'mobile_developer'       => ['android developer', 'ios developer', 'flutter developer'],
    'devops_engineer'        => ['devops', 'sysadmin'],
    'cybersecurity_analyst'  => ['cybersecurity', 'cyber security', 'keamanan siber', 'pentester', 'security analyst'],
    'qa_engineer'            => ['qa', 'tester', 'penguji perangkat lunak'],
    'database_administrator' => ['dba', 'admin database'],
    'it_project_manager'     => ['project manager', 'manajer proyek'],
];

/* ---------------------------------------------------------------- blok jawaban */

function botT(string $teks): array { return ['t' => 'text', 'v' => $teks]; }
function botL(array $baris): array { return ['t' => 'list', 'v' => array_values($baris)]; }
function botA(string $href, string $label): array { return ['t' => 'link', 'href' => $href, 'v' => $label]; }
function botJawaban(array $blok, array $saran = []): array { return ['blocks' => $blok, 'suggest' => array_slice($saran, 0, 4)]; }

/* ---------------------------------------------------------------- data */

/** Mengumpulkan semua data yang dibutuhkan untuk menjawab satu pertanyaan. */
function botKonteks(PDO $pdo, int $userId): array
{
    $profil = loadProfile($pdo, $userId);
    $kb     = kbKnowledge();
    $cfg    = kbConfig();

    $kodeSkill = array_column($kb['skills'], 'code');
    $kodeCert  = array_column($kb['certifications'], 'code');
    $profil['skills'] = array_filter($profil['skills'], fn($kode) => in_array($kode, $kodeSkill, true), ARRAY_FILTER_USE_KEY);
    $profil['certs']  = array_values(array_intersect($profil['certs'], $kodeCert));

    $punyaProfil = !empty($profil['skills']);
    $hasil = $punyaProfil && $kb['careers'] ? hitungKecocokan($profil, $kb, $cfg) : [];
    $peringkat = [];
    foreach ($hasil as $i => $r) {
        $peringkat[$r['careerCode']] = ['rank' => $i + 1, 'data' => $r];
    }

    $karier = [];
    foreach ($kb['careers'] as $k) {
        $karier[$k['code']] = $k;
    }
    $skill = [];
    foreach ($kb['skills'] as $s) {
        $skill[$s['code']] = $s;
    }
    $cert = [];
    foreach ($kb['certifications'] as $c) {
        $cert[$c['code']] = $c;
    }

    return [
        'profil' => $profil, 'punyaProfil' => $punyaProfil, 'karier' => $karier, 'skill' => $skill,
        'cert' => $cert, 'peringkat' => $peringkat, 'urut' => array_column($hasil, 'careerCode'),
        'analisisTerakhir' => listAssessments($pdo, $userId, 1)[0]['id'] ?? null,
    ];
}

/* ---------------------------------------------------------------- mengenali karier & skill */

/** Kata kunci untuk mengenali sebuah skill dari namanya. "Docker & CI/CD" -> "docker & ci/cd", "docker". */
function botKataKunciSkill(array $s): array
{
    $kunci = [$s['name']];
    foreach (preg_split('/[\/&()]/u', $s['name']) as $bagian) {
        $bagian = trim($bagian);
        if (mb_strlen($bagian) >= 3) {
            $kunci[] = $bagian;
        }
    }
    $kode = str_replace('_', ' ', $s['code']);
    if (mb_strlen($kode) >= 3) {
        $kunci[] = $kode;
    }
    return array_values(array_unique($kunci));
}

/**
 * Mencari karier dan skill yang disebut dalam teks.
 * @return array ['karier' => [[code, pos, len], ...], 'skill' => [...]] terurut sesuai urutan muncul
 */
function botKenali(string $teks, array $ctx): array
{
    $padded = engToken($teks);
    $cari = function (array $kandidat) use ($padded): array {
        $temu = [];
        foreach ($kandidat as $kode => $daftarKunci) {
            foreach ($daftarKunci as $kunci) {
                $k = engToken($kunci);
                if (trim($k) === '') {
                    continue;
                }
                $pos = strpos($padded, $k);
                if ($pos !== false && (!isset($temu[$kode]) || strlen($k) > $temu[$kode]['len'])) {
                    $temu[$kode] = ['code' => $kode, 'pos' => $pos, 'len' => strlen(trim($k))];
                }
            }
        }
        usort($temu, fn($a, $b) => $a['pos'] <=> $b['pos']);
        return array_values($temu);
    };

    $kandidatKarier = [];
    foreach ($ctx['karier'] as $kode => $k) {
        $kandidatKarier[$kode] = array_merge([$k['name']], BOT_ALIAS_KARIER[$kode] ?? []);
    }
    $kandidatSkill = [];
    foreach ($ctx['skill'] as $kode => $s) {
        $kandidatSkill[$kode] = botKataKunciSkill($s);
    }
    return ['karier' => $cari($kandidatKarier), 'skill' => $cari($kandidatSkill)];
}

/* ---------------------------------------------------------------- bagian-bagian jawaban */

function botNamaKarier(array $ctx, string $kode): string { return $ctx['karier'][$kode]['name'] ?? $kode; }
function botNamaSkill(array $ctx, string $kode): string { return $ctx['skill'][$kode]['name'] ?? $kode; }

function botBantuan(): array
{
    return botJawaban([
        botT('Aku asisten karier. Aku menjawab dari knowledge base dan hasil analisis profilmu, jadi tidak mengarang.'),
        botT('Kamu bisa menanyakan:'),
        botL([
            'Karier apa yang paling cocok untukku, dan kenapa?',
            'Skill apa yang masih kurang untuk karier tertentu?',
            'Penjelasan sebuah karier atau skill',
            'Perbedaan dua karier',
            'Sertifikasi yang relevan untuk sebuah karier',
        ]),
    ], [
        'Karier apa yang paling cocok untukku?',
        'Skill apa yang harus kupelajari dulu?',
        'Apa itu Data Analyst?',
        'Apa bedanya System Analyst dan Data Analyst?',
    ]);
}

function botSapaan(): array
{
    return botJawaban([botT('Halo! Aku asisten karier. Mau mulai dari mana?')], [
        'Karier apa yang paling cocok untukku?',
        'Skill apa yang harus kupelajari dulu?',
        'Apa itu Data Analyst?',
    ]);
}

function botBelumAdaProfil(): array
{
    return botJawaban([
        botT('Aku belum bisa menilai kecocokanmu karena kamu belum memilih skill di profil.'),
        botA('profile.php', 'Isi profil'),
    ], ['Apa itu Data Analyst?', 'Apa bedanya System Analyst dan Data Analyst?']);
}

/** Pilih karier yang dimaksud: yang disebut, yang dibahas sebelumnya, atau karier teratas milik pengguna. */
function botPilihKarier(array $kenal, array $ctx, string $teks): ?string
{
    if ($kenal['karier']) {
        return $kenal['karier'][0]['code'];
    }
    $ingat = $_SESSION['bot_karier'] ?? null;
    if ($ingat && isset($ctx['karier'][$ingat]) && preg_match('/\b(itu|tersebut|tadi|nya|yang tadi)\b/u', $teks)) {
        return $ingat;
    }
    return $ctx['urut'][0] ?? null;
}

function botMintaKarier(string $contoh): array
{
    return botJawaban([botT('Karier mana yang kamu maksud? Sebutkan namanya, misalnya: "' . $contoh . '".')],
        ['Karier apa yang paling cocok untukku?', 'Apa itu Data Analyst?']);
}

function botRingkasHasil(array $ctx): array
{
    if (!$ctx['punyaProfil']) {
        return botBelumAdaProfil();
    }
    $baris = [];
    foreach (array_slice($ctx['urut'], 0, 3) as $i => $kode) {
        $r = $ctx['peringkat'][$kode]['data'];
        $baris[] = $r['careerName'] . ': ' . (int) round($r['score']) . '% (' . $r['label'] . ')';
    }
    $teratas = $ctx['peringkat'][$ctx['urut'][0]]['data'];
    $blok = [botT('Berdasarkan profilmu saat ini, tiga karier yang paling cocok, dari yang teratas:'), botL($baris), botT($teratas['summary'])];
    if ($ctx['analisisTerakhir']) {
        $blok[] = botA('result.php?id=' . (int) $ctx['analisisTerakhir'], 'Buka hasil analisis lengkap');
    }
    return botJawaban($blok, [
        'Skill apa yang kurang untuk ' . $teratas['careerName'] . '?',
        'Kenapa skorku untuk ' . $teratas['careerName'] . ' segitu?',
        'Sertifikasi untuk ' . $teratas['careerName'],
    ]);
}

function botInfoKarier(string $kode, array $ctx): array
{
    $k = $ctx['karier'][$kode];
    $butuh = $k['requirements'];
    usort($butuh, fn($a, $b) => $b['weight'] <=> $a['weight']);
    $baris = [];
    foreach (array_slice($butuh, 0, 6) as $r) {
        $baris[] = botNamaSkill($ctx, $r['skillCode']) . ' (level ' . $r['requiredLevel'] . ', bobot ' . $r['weight'] . ')';
    }
    $syarat = 'Pendidikan minimal: ' . (NAMA_JENJANG[$k['minEducation']] ?? '-') . '.';
    if ($k['preferredMajors']) {
        $syarat .= ' Jurusan yang umum: ' . implode(', ', array_slice($k['preferredMajors'], 0, 5)) . '.';
    }
    $blok = [botT($k['name'] . ': ' . $k['description']), botT('Skill utama yang dibutuhkan:'), botL($baris), botT($syarat)];
    if ($ctx['punyaProfil'] && isset($ctx['peringkat'][$kode])) {
        $p = $ctx['peringkat'][$kode];
        $blok[] = botT('Kecocokanmu saat ini: ' . (int) round($p['data']['score']) . '% (peringkat ' . $p['rank'] . ' dari ' . count($ctx['urut']) . ').');
    }
    $_SESSION['bot_karier'] = $kode;
    return botJawaban($blok, [
        'Skill apa yang kurang untuk ' . $k['name'] . '?',
        'Sertifikasi untuk ' . $k['name'],
        'Kenapa skorku untuk ' . $k['name'] . ' segitu?',
    ]);
}

/** Skill yang dibutuhkan sebuah karier. Bila pengguna punya profil dan bertanya soal dirinya, tampilkan celahnya. */
function botSkillKarier(string $kode, array $ctx, bool $umum): array
{
    $k = $ctx['karier'][$kode];
    $_SESSION['bot_karier'] = $kode;

    if ($umum || !$ctx['punyaProfil'] || !isset($ctx['peringkat'][$kode])) {
        $butuh = $k['requirements'];
        usort($butuh, fn($a, $b) => $b['weight'] <=> $a['weight']);
        $baris = array_map(fn($r) => botNamaSkill($ctx, $r['skillCode']) . ': minimal level ' . $r['requiredLevel'] . ' (bobot ' . $r['weight'] . ')', $butuh);
        $blok = [botT('Skill yang dibutuhkan untuk ' . $k['name'] . ', diurutkan dari yang paling penting:'), botL($baris)];
        if (!$ctx['punyaProfil']) {
            $blok[] = botT('Isi profilmu supaya aku bisa menunjukkan mana yang masih kurang.');
            $blok[] = botA('profile.php', 'Isi profil');
        }
        return botJawaban($blok, ['Sertifikasi untuk ' . $k['name'], 'Apa itu ' . $k['name'] . '?']);
    }

    $r = $ctx['peringkat'][$kode]['data'];
    if (!$r['gaps']) {
        return botJawaban([botT('Semua skill utama ' . $k['name'] . ' sudah memenuhi level yang dibutuhkan. Fokuslah pada pengalaman dan portofolio.')],
            ['Sertifikasi untuk ' . $k['name']]);
    }
    $baris = [];
    foreach (array_slice($r['gaps'], 0, 4) as $g) {
        $baris[] = $g['name'] . ': levelmu ' . $g['userLevel'] . ', dibutuhkan ' . $g['requiredLevel']
            . ($g['learningTip'] ? '. Saran: ' . $g['learningTip'] : '');
    }
    $blok = [
        botT('Untuk ' . $k['name'] . ', ini yang paling perlu kamu kejar dulu (diurutkan dari yang paling berpengaruh ke skor):'),
        botL($baris),
        botT(count($r['strengths']) . ' dari ' . count($r['skills']) . ' skill utama sudah kamu penuhi.'),
    ];
    if ($ctx['analisisTerakhir']) {
        $blok[] = botA('result.php?id=' . (int) $ctx['analisisTerakhir'], 'Lihat rincian di hasil analisis');
    }
    return botJawaban($blok, ['Sertifikasi untuk ' . $k['name'], 'Kenapa skorku untuk ' . $k['name'] . ' segitu?']);
}

function botAlasanSkor(string $kode, array $ctx): array
{
    if (!$ctx['punyaProfil'] || !isset($ctx['peringkat'][$kode])) {
        return botBelumAdaProfil();
    }
    $_SESSION['bot_karier'] = $kode;
    $r = $ctx['peringkat'][$kode]['data'];
    $b = $r['breakdown'];
    $baris = [
        'Skill: ' . (int) round($b['skills']['score']) . '% (bobot ' . $b['skills']['weightPct'] . '%)',
        'Pendidikan: ' . (int) round($b['education']['score']) . '% (bobot ' . $b['education']['weightPct'] . '%). '
            . ($b['education']['levelMet'] ? 'Jenjang terpenuhi' : 'Butuh minimal ' . $b['education']['minEducationLabel'])
            . ', ' . ($b['education']['majorMatch'] ? 'jurusan sesuai.' : 'jurusan kurang umum untuk posisi ini.'),
        'Pengalaman: ' . (int) round($b['experience']['score']) . '% (bobot ' . $b['experience']['weightPct'] . '%). '
            . $b['experience']['relevantYears'] . ' tahun relevan dari ' . $b['experience']['idealYears'] . ' tahun ideal.',
    ];
    if ($b['certification']) {
        $baris[] = 'Sertifikasi: ' . (int) round($b['certification']['score']) . '% (bobot ' . $b['certification']['weightPct'] . '%)';
    }
    return botJawaban([
        botT('Skormu untuk ' . $r['careerName'] . ' adalah ' . (int) round($r['score']) . '% (' . $r['label'] . '), dari empat bagian:'),
        botL($baris),
        botT($r['summary']),
    ], ['Skill apa yang kurang untuk ' . $r['careerName'] . '?', 'Sertifikasi untuk ' . $r['careerName']]);
}

function botSertifikasi(string $kode, array $ctx): array
{
    $k = $ctx['karier'][$kode];
    $_SESSION['bot_karier'] = $kode;
    $punya = array_flip($ctx['profil']['certs']);
    $daftar = $k['certifications'];
    usort($daftar, fn($a, $b) => $b['bonusWeight'] <=> $a['bonusWeight']);
    $baris = [];
    foreach ($daftar as $c) {
        if (!isset($ctx['cert'][$c['certCode']])) {
            continue;
        }
        $info = $ctx['cert'][$c['certCode']];
        $baris[] = $info['name'] . ' (' . $info['issuer'] . ')' . (isset($punya[$c['certCode']]) ? ' - sudah kamu miliki' : '');
    }
    if (!$baris) {
        return botJawaban([botT('Belum ada sertifikasi yang terdaftar untuk ' . $k['name'] . ' di knowledge base.')]);
    }
    return botJawaban([
        botT('Sertifikasi yang relevan untuk ' . $k['name'] . ', dari yang paling berpengaruh:'),
        botL($baris),
        botT('Memiliki satu sertifikasi utama sudah cukup untuk nilai penuh pada komponen sertifikasi.'),
    ], ['Skill apa yang kurang untuk ' . $k['name'] . '?', 'Apa itu ' . $k['name'] . '?']);
}

function botBandingkan(string $a, string $b, array $ctx): array
{
    $ka = $ctx['karier'][$a];
    $kb = $ctx['karier'][$b];
    $namaSkill = fn(array $k) => array_column($k['requirements'], 'skillCode');
    $sa = $namaSkill($ka);
    $sb = $namaSkill($kb);
    $sama = array_intersect($sa, $sb);
    $hanya = function (array $k, array $lain) use ($ctx) {
        $r = array_filter($k['requirements'], fn($x) => !in_array($x['skillCode'], $lain, true));
        usort($r, fn($x, $y) => $y['weight'] <=> $x['weight']);
        return array_map(fn($x) => botNamaSkill($ctx, $x['skillCode']), array_slice($r, 0, 4));
    };

    $blok = [
        botT($ka['name'] . ': ' . $ka['description']),
        botT($kb['name'] . ': ' . $kb['description']),
        botT('Skill yang sama-sama dibutuhkan:'),
        $sama ? botL(array_map(fn($c) => botNamaSkill($ctx, $c), $sama)) : botT('Tidak ada yang sama.'),
        botT('Yang khas untuk ' . $ka['name'] . ':'),
        botL($hanya($ka, $sb) ?: ['(tidak ada)']),
        botT('Yang khas untuk ' . $kb['name'] . ':'),
        botL($hanya($kb, $sa) ?: ['(tidak ada)']),
        botT('Pendidikan minimal: ' . $ka['name'] . ' ' . (NAMA_JENJANG[$ka['minEducation']] ?? '-') . ', ' . $kb['name'] . ' ' . (NAMA_JENJANG[$kb['minEducation']] ?? '-') . '.'),
    ];
    if ($ctx['punyaProfil'] && isset($ctx['peringkat'][$a], $ctx['peringkat'][$b])) {
        $blok[] = botT('Kecocokanmu: ' . $ka['name'] . ' ' . (int) round($ctx['peringkat'][$a]['data']['score']) . '%, '
            . $kb['name'] . ' ' . (int) round($ctx['peringkat'][$b]['data']['score']) . '%.');
    }
    return botJawaban($blok, ['Skill apa yang kurang untuk ' . $ka['name'] . '?', 'Skill apa yang kurang untuk ' . $kb['name'] . '?']);
}

function botInfoSkill(string $kode, array $ctx): array
{
    $s = $ctx['skill'][$kode];
    $dipakai = [];
    foreach ($ctx['karier'] as $k) {
        foreach ($k['requirements'] as $r) {
            if ($r['skillCode'] === $kode) {
                $dipakai[$k['name']] = 'level ' . $r['requiredLevel'];
            }
        }
    }
    $blok = [botT($s['name'] . ' (kategori ' . $s['category'] . ').')];
    if ($dipakai) {
        $blok[] = botT('Dibutuhkan untuk:');
        $blok[] = botL(array_map(fn($n, $l) => "$n ($l)", array_keys($dipakai), $dipakai));
    }
    if (!empty($s['learningTip'])) {
        $blok[] = botT('Cara belajar: ' . $s['learningTip']);
    }
    if (!empty($s['learningUrl']) && preg_match('#^https?://#i', $s['learningUrl'])) {
        $blok[] = botA($s['learningUrl'], 'Buka materi belajar');
    }
    $level = $ctx['profil']['skills'][$kode] ?? 0;
    $blok[] = botT($level > 0 ? "Levelmu saat ini: $level dari 5." : 'Kamu belum mengisi skill ini di profil.');

    $saran = [];
    foreach (array_slice(array_keys($dipakai), 0, 2) as $nama) {
        $saran[] = 'Apa itu ' . $nama . '?';
    }
    return botJawaban($blok, $saran);
}

/** Cadangan: pencarian arti di Qdrant untuk pertanyaan bebas. */
function botCariArti(string $teks): array
{
    $minimal = (float) qkbEnv('CHATBOT_MIN_SCORE', '0.80');
    try {
        $hasil = qkbCari($teks, 4);
    } catch (Throwable $e) {
        return botJawaban([botT('Pencarian sedang tidak bisa dipakai. Coba pertanyaan yang lebih spesifik, misalnya menyebut nama karier atau skill.')],
            ['Karier apa yang paling cocok untukku?', 'Apa itu Data Analyst?']);
    }
    $hasil = array_values(array_filter($hasil, fn($h) => $h['score'] >= $minimal));
    if (!$hasil) {
        return botJawaban([
            botT('Maaf, aku belum menemukan yang cocok di knowledge base untuk pertanyaan itu. Aku hanya tahu soal karier IT, skill, dan sertifikasinya.'),
            botT('Coba tanyakan dengan menyebut nama karier atau skill.'),
        ], ['Karier apa yang paling cocok untukku?', 'Apa itu Data Analyst?', 'Apa itu SQL?']);
    }
    $baris = [];
    $saran = [];
    foreach ($hasil as $h) {
        $p = $h['payload'];
        $jenis = ($p['type'] ?? '') === 'career' ? 'Karier' : 'Skill';
        $baris[] = $jenis . ': ' . ($p['name'] ?? '?') . ' (kemiripan ' . (int) round($h['score'] * 100) . '%)';
        $saran[] = ($p['type'] ?? '') === 'career' ? 'Ceritakan tentang ' . $p['name'] : 'Apa itu ' . $p['name'] . '?';
    }
    return botJawaban([botT('Yang paling dekat dengan pertanyaanmu di knowledge base:'), botL($baris)], $saran);
}

/* ---------------------------------------------------------------- pintu masuk */

function botJawab(PDO $pdo, array $user, string $pesan): array
{
    $pesan = trim($pesan);
    $t = mb_strtolower($pesan);
    if ($t === '') {
        return botBantuan();
    }

    $has = fn(string $pola) => (bool) preg_match('/' . $pola . '/u', $t);

    if ($has('^(halo|hai|hi|hei|hello|selamat (pagi|siang|sore|malam)|assalamualaikum|permisi)\b') && mb_strlen($t) < 30) {
        return botSapaan();
    }
    if ($has('\b(bantuan|help|bisa apa|fitur|cara pakai|menu)\b')) {
        return botBantuan();
    }
    if ($has('\b(gaji|salary|lowongan|loker|harga|biaya kursus|perusahaan mana)\b')) {
        return botJawaban([botT('Maaf, data seperti gaji, lowongan, atau biaya kursus belum ada di knowledge base, jadi aku tidak mau menebak.'),
            botT('Yang bisa kujawab: kecocokan karier, skill yang dibutuhkan, dan sertifikasi.')], ['Karier apa yang paling cocok untukku?']);
    }

    $ctx   = botKonteks($pdo, (int) $user['id']);
    $kenal = botKenali($pesan, $ctx);
    $kar   = $kenal['karier'];
    $skl   = $kenal['skill'];

    // Bila skill disebut dengan nama yang lebih panjang daripada nama karier ("UI Design" vs alias "ui"), utamakan skill.
    if ($kar && $skl && $skl[0]['len'] > $kar[0]['len']) {
        $kar = [];
    }

    if (count($kar) >= 2 && $has('\b(bandingkan|beda|bedanya|perbedaan|versus|vs|dibanding|atau)\b')) {
        return botBandingkan($kar[0]['code'], $kar[1]['code'], $ctx);
    }
    if ($has('sertifikat|sertifikasi')) {
        $kode = botPilihKarier(['karier' => $kar], $ctx, $t);
        return $kode ? botSertifikasi($kode, $ctx) : botMintaKarier('Sertifikasi untuk Data Analyst');
    }
    if ($has('\b(kenapa|mengapa|alasan)\b') && $has('skor|persen|cocok|peringkat|nilai')) {
        $kode = botPilihKarier(['karier' => $kar], $ctx, $t);
        return $kode ? botAlasanSkor($kode, $ctx) : botBelumAdaProfil();
    }
    if ($has('skill|kemampuan|kompetensi|pelajar|belajar|kurang|\bgap\b|kuasai|tingkatkan|\bsyarat|dibutuhkan|diperlukan')) {
        if (!$kar && $skl && !$has('kurang|\bgap\b|pelajar|dulu')) {
            return botInfoSkill($skl[0]['code'], $ctx);
        }
        $kode = botPilihKarier(['karier' => $kar], $ctx, $t);
        if ($kode) {
            $umum = $has('\b(dibutuhkan|diperlukan|syarat|apa saja|apa aja)\b') && $kar;
            return botSkillKarier($kode, $ctx, (bool) $umum);
        }
        return botMintaKarier('Skill apa yang dibutuhkan untuk Data Analyst?');
    }
    if (!$kar && !$skl && $has('cocok|rekomendasi|peringkat|hasil|jadi apa|karier apa|pekerjaan apa')) {
        return botRingkasHasil($ctx);
    }
    if ($kar) {
        return botInfoKarier($kar[0]['code'], $ctx);
    }
    if ($skl) {
        return botInfoSkill($skl[0]['code'], $ctx);
    }
    return botCariArti($pesan);
}
