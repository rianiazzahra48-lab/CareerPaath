<?php
/**
 * MESIN PENGHITUNG KECOCOKAN KARIER
 * ----------------------------------------------------------------
 * File ini TIDAK memakai database sama sekali. Ia hanya menerima data lalu
 * mengembalikan hasil hitungan:
 *   - $profil : data pengguna (dari MySQL)
 *   - $kb     : pengetahuan karier (dari MongoDB)
 *   - $cfg    : bobot dan ambang (dari MongoDB)
 *
 * Rumus skor akhir (0-100):
 *   skor = 100 x (Ws*Skill + We*Pendidikan + Wx*Pengalaman + Wc*Sertifikasi) / jumlah bobot yang dipakai
 *
 *   Skill       = jumlah( bobot x min(level_kamu / level_dibutuhkan, 1) ) / jumlah bobot
 *   Pendidikan  = 0.6 x min(jenjang_kamu / jenjang_minimal, 1) + 0.4 x (jurusan cocok ? 1 : 0.4)
 *   Pengalaman  = min(tahun_relevan / tahun_ideal, 1)
 *   Sertifikasi = min(bobot_dimiliki / bobot_tertinggi, 1)   (dilewati kalau karier tidak punya sertifikasi)
 */

const NAMA_JENJANG = [1 => 'SMA/SMK', 2 => 'Diploma (D3)', 3 => 'Sarjana (S1/D4)', 4 => 'Magister (S2)', 5 => 'Doktor (S3)'];

/** Singkatan jurusan yang umum dipakai, supaya "MI" dikenali sebagai Manajemen Informatika. */
const SINGKATAN_JURUSAN = [
    'si'    => 'sistem informasi',
    'ti'    => 'teknik informatika',
    'tif'   => 'teknik informatika',
    'mi'    => 'manajemen informatika',
    'tk'    => 'teknik komputer',
    'ilkom' => 'ilmu komputer',
    'dkv'   => 'desain komunikasi visual',
    'te'    => 'teknik elektro',
    'tekom' => 'teknik komputer',
];

/** Mengubah teks jadi kata-kata utuh berpagar spasi. "front-end" menjadi "frontend". */
function engToken(string $teks): string
{
    $t = mb_strtolower(trim($teks));
    $t = str_replace('-', '', $t);
    $t = preg_replace('/[^a-z0-9]+/', ' ', $t);
    return ' ' . trim($t) . ' ';
}

/** Cocok sebagai kata utuh, sehingga "ml" tidak cocok dengan "html". */
function engAdaKataKunci(string $teksBerpagar, string $kataKunci): bool
{
    $k = engToken($kataKunci);
    return trim($k) !== '' && str_contains($teksBerpagar, $k);
}

function engJurusanCocok(string $jurusan, array $disukai): bool
{
    if (!$disukai) {
        return true;
    }
    $m = mb_strtolower(trim($jurusan));
    if ($m === '') {
        return false;
    }
    $m = SINGKATAN_JURUSAN[$m] ?? $m;
    foreach ($disukai as $p) {
        $p = mb_strtolower($p);
        if ($m === $p || (mb_strlen($m) >= 4 && (str_contains($m, $p) || str_contains($p, $m)))) {
            return true;
        }
    }
    return false;
}

function engLabel(float $skor, array $cfg): string
{
    if ($skor >= $cfg['threshold_high']) {
        return 'Sangat Cocok';
    }
    if ($skor >= $cfg['threshold_medium']) {
        return 'Cocok';
    }
    if ($skor >= $cfg['threshold_low']) {
        return 'Cukup Cocok';
    }
    return 'Perlu Pengembangan';
}

function engHitungSkill(array $karier, array $skillUser, array $infoSkill): array
{
    $totalBobot = 0;
    $didapat = 0.0;
    $item = [];

    foreach ($karier['requirements'] as $req) {
        $info = $infoSkill[$req['skillCode']] ?? null;
        if (!$info) {
            continue; // skill sudah dihapus dari knowledge base
        }
        $levelUser = $skillUser[$req['skillCode']] ?? 0;
        $rasio = min($levelUser / $req['requiredLevel'], 1);
        $totalBobot += $req['weight'];
        $didapat += $req['weight'] * $rasio;

        $item[] = [
            'skillCode'     => $req['skillCode'],
            'name'          => $info['name'],
            'category'      => $info['category'],
            'requiredLevel' => $req['requiredLevel'],
            'userLevel'     => $levelUser,
            'weight'        => $req['weight'],
            'gap'           => max($req['requiredLevel'] - $levelUser, 0),
            'status'        => $levelUser >= $req['requiredLevel'] ? 'strong' : ($levelUser > 0 ? 'partial' : 'missing'),
            'learningTip'   => $info['learningTip'] ?? null,
            'learningUrl'   => $info['learningUrl'] ?? null,
        ];
    }
    return ['score' => $totalBobot ? $didapat / $totalBobot : 0.0, 'items' => $item];
}

function engHitungPendidikan(array $karier, array $profil): array
{
    $min = max(1, $karier['minEducation']);
    $level = max(1, (int) $profil['education_level']);
    $skorJenjang = min($level / $min, 1);
    $cocok = engJurusanCocok((string) $profil['major'], $karier['preferredMajors']);
    return [
        'score'             => 0.6 * $skorJenjang + 0.4 * ($cocok ? 1 : 0.4),
        'levelMet'          => $level >= $min,
        'majorMatch'        => $cocok,
        'minEducationLabel' => NAMA_JENJANG[$min] ?? '',
    ];
}

function engHitungPengalaman(array $karier, array $profil): array
{
    $relevan = 0.0;
    foreach ($profil['experiences'] as $e) {
        $teks = engToken(($e['title'] ?? '') . ' ' . ($e['description'] ?? ''));
        foreach ($karier['experienceKeywords'] as $k) {
            if (engAdaKataKunci($teks, $k)) {
                $relevan += (float) ($e['years'] ?? 0);
                break;
            }
        }
    }
    $ideal = $karier['idealExperienceYears'];
    return [
        'score'         => $ideal > 0 ? min($relevan / $ideal, 1) : 1.0,
        'relevantYears' => round($relevan, 1),
        'idealYears'    => $ideal,
    ];
}

function engHitungSertifikasi(array $karier, array $profil, array $infoCert): ?array
{
    $daftar = array_values(array_filter($karier['certifications'], fn($c) => isset($infoCert[$c['certCode']])));
    if (!$daftar) {
        return null;
    }
    $dimiliki = array_flip($profil['certs']);
    $maks = max(array_column($daftar, 'bonusWeight'));
    $dapat = 0;
    $punya = [];
    $kurang = [];
    foreach ($daftar as $c) {
        $info = $infoCert[$c['certCode']];
        $baris = ['certCode' => $c['certCode'], 'name' => $info['name'], 'issuer' => $info['issuer'], 'bonusWeight' => $c['bonusWeight']];
        if (isset($dimiliki[$c['certCode']])) {
            $dapat += $c['bonusWeight'];
            $punya[] = $baris;
        } else {
            $kurang[] = $baris;
        }
    }
    usort($kurang, fn($a, $b) => $b['bonusWeight'] <=> $a['bonusWeight']);
    return ['score' => min($dapat / $maks, 1), 'owned' => $punya, 'missing' => $kurang];
}

function engRingkasan(array $karier, array $skill, array $edu, array $exp, ?array $cert): string
{
    $kuat = count(array_filter($skill['items'], fn($s) => $s['status'] === 'strong'));
    $bagian = ["$kuat dari " . count($skill['items']) . ' skill utama sudah memenuhi standar'];
    if (!$edu['levelMet']) {
        $bagian[] = 'jenjang pendidikan minimal ' . $edu['minEducationLabel'] . ' belum terpenuhi';
    }
    if (!$edu['majorMatch']) {
        $bagian[] = 'jurusan belum termasuk yang umum untuk posisi ini';
    }
    if ($exp['idealYears'] > 0) {
        $bagian[] = 'pengalaman relevan ' . $exp['relevantYears'] . ' dari ' . $exp['idealYears'] . ' tahun ideal';
    }
    if ($cert && !$cert['owned']) {
        $bagian[] = 'belum memiliki sertifikasi pendukung';
    }
    return $karier['name'] . ': ' . implode('; ', $bagian) . '.';
}

function engNilaiKarier(array $karier, array $profil, array $infoSkill, array $infoCert, array $cfg): array
{
    $skill = engHitungSkill($karier, $profil['skills'], $infoSkill);
    $edu   = engHitungPendidikan($karier, $profil);
    $exp   = engHitungPengalaman($karier, $profil);
    $cert  = engHitungSertifikasi($karier, $profil, $infoCert);

    $bagian = [
        ['bobot' => $cfg['weight_skill'], 'skor' => $skill['score']],
        ['bobot' => $cfg['weight_education'], 'skor' => $edu['score']],
        ['bobot' => $cfg['weight_experience'], 'skor' => $exp['score']],
    ];
    if ($cert) {
        $bagian[] = ['bobot' => $cfg['weight_certification'], 'skor' => $cert['score']];
    }
    $totalBobot = array_sum(array_column($bagian, 'bobot')) ?: 1;
    $mentah = 0;
    foreach ($bagian as $b) {
        $mentah += $b['bobot'] * $b['skor'];
    }
    $skor = round($mentah / $totalBobot * 100, 1);
    $persen = fn(array $b) => (int) round($b['bobot'] / $totalBobot * 100);

    $item = $skill['items'];
    $kuat = array_values(array_filter($item, fn($s) => $s['status'] === 'strong'));
    usort($kuat, fn($a, $b) => $b['weight'] <=> $a['weight']);
    $celah = array_values(array_filter($item, fn($s) => $s['status'] !== 'strong'));
    usort($celah, fn($a, $b) => ($b['weight'] * $b['gap']) <=> ($a['weight'] * $a['gap']));
    usort($item, fn($a, $b) => $b['weight'] <=> $a['weight']);

    return [
        'careerCode'   => $karier['code'],
        'careerName'   => $karier['name'],
        'description'  => $karier['description'],
        'score'        => $skor,
        'label'        => engLabel($skor, $cfg),
        'breakdown'    => [
            'skills'        => ['score' => round($skill['score'] * 100, 1), 'weightPct' => $persen($bagian[0])],
            'education'     => [
                'score' => round($edu['score'] * 100, 1), 'weightPct' => $persen($bagian[1]),
                'levelMet' => $edu['levelMet'], 'majorMatch' => $edu['majorMatch'], 'minEducationLabel' => $edu['minEducationLabel'],
            ],
            'experience'    => [
                'score' => round($exp['score'] * 100, 1), 'weightPct' => $persen($bagian[2]),
                'relevantYears' => $exp['relevantYears'], 'idealYears' => $exp['idealYears'],
            ],
            'certification' => $cert ? ['score' => round($cert['score'] * 100, 1), 'weightPct' => $persen($bagian[3])] : null,
        ],
        'skills'         => $item,
        'strengths'      => $kuat,
        'gaps'           => $celah,
        'certifications' => $cert ? ['owned' => $cert['owned'], 'missing' => $cert['missing']] : ['owned' => [], 'missing' => []],
        'summary'        => engRingkasan($karier, $skill, $edu, $exp, $cert),
    ];
}

/**
 * @param array $profil ['education_level'=>int, 'major'=>string, 'skills'=>[kode=>level], 'certs'=>[kode], 'experiences'=>[...]]
 * @param array $kb     ['skills'=>[], 'certifications'=>[], 'careers'=>[]]
 * @param array $cfg    bobot dan ambang dari scoring_config
 * @return array semua karier, diurutkan dari skor tertinggi
 */
function hitungKecocokan(array $profil, array $kb, array $cfg): array
{
    $infoSkill = [];
    foreach ($kb['skills'] as $s) {
        $infoSkill[$s['code']] = $s;
    }
    $infoCert = [];
    foreach ($kb['certifications'] as $c) {
        $infoCert[$c['code']] = $c;
    }

    $hasil = [];
    foreach ($kb['careers'] as $karier) {
        $hasil[] = engNilaiKarier($karier, $profil, $infoSkill, $infoCert, $cfg);
    }
    usort($hasil, fn($a, $b) => $b['score'] <=> $a['score'] ?: strcasecmp($a['careerName'], $b['careerName']));
    return $hasil;
}
