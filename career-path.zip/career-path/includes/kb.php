<?php
// Membaca pengetahuan (skill, sertifikasi) dari MongoDB.
// Memakai fungsi mongoFindMany() yang sudah ada di includes/mongo.php.

require_once __DIR__ . '/mongo.php';

/**
 * Mengubah hasil MongoDB (bisa berupa array atau objek) menjadi array biasa,
 * supaya kode lain tidak peduli bentuk aslinya.
 */
function kbNormalize($dokumen): array
{
    $hasil = [];
    foreach ($dokumen as $doc) {
        $baris = json_decode(json_encode($doc), true);
        if (is_array($baris) && isset($baris['_id'])) {
            $hasil[] = $baris;
        }
    }
    return $hasil;
}

/** Daftar skill: [['code'=>'sql', 'name'=>'SQL & Basis Data', 'category'=>'Data'], ...] */
function kbSkills(): array
{
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }
    $daftar = [];
    foreach (kbNormalize(mongoFindMany('skills', [])) as $d) {
        $daftar[] = [
            'code'     => (string) $d['_id'],
            'name'     => (string) ($d['name'] ?? $d['_id']),
            'category' => (string) ($d['category'] ?? 'Lainnya'),
            'learningTip' => $d['learningTip'] ?? null,
            'learningUrl' => $d['learningUrl'] ?? null,
        ];
    }
    usort($daftar, fn($a, $b) => strcasecmp($a['category'], $b['category']) ?: strcasecmp($a['name'], $b['name']));
    return $cache = $daftar;
}

/** Daftar sertifikasi: [['code'=>'psm1', 'name'=>'...', 'issuer'=>'...'], ...] */
function kbCertifications(): array
{
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }
    $daftar = [];
    foreach (kbNormalize(mongoFindMany('certifications', [])) as $d) {
        $daftar[] = [
            'code'   => (string) $d['_id'],
            'name'   => (string) ($d['name'] ?? $d['_id']),
            'issuer' => (string) ($d['issuer'] ?? ''),
        ];
    }
    usort($daftar, fn($a, $b) => strcasecmp($a['name'], $b['name']));
    return $cache = $daftar;
}

/** Daftar karier lengkap dengan kebutuhan skill dan sertifikasinya. */
function kbCareers(): array
{
    $daftar = [];
    foreach (kbNormalize(mongoFindMany('careers', [])) as $d) {
        $daftar[] = [
            'code'                 => (string) $d['_id'],
            'name'                 => (string) ($d['name'] ?? $d['_id']),
            'description'          => (string) ($d['description'] ?? ''),
            'minEducation'         => (int) ($d['minEducation'] ?? 1),
            'preferredMajors'      => array_map('strval', (array) ($d['preferredMajors'] ?? [])),
            'experienceKeywords'   => array_map('strval', (array) ($d['experienceKeywords'] ?? [])),
            'idealExperienceYears' => (float) ($d['idealExperienceYears'] ?? 0),
            'requirements'         => array_map(fn($r) => [
                'skillCode'     => (string) $r['skillCode'],
                'requiredLevel' => max(1, (int) $r['requiredLevel']),
                'weight'        => max(1, (int) $r['weight']),
            ], (array) ($d['requirements'] ?? [])),
            'certifications'       => array_map(fn($r) => [
                'certCode'    => (string) $r['certCode'],
                'bonusWeight' => max(1, (int) $r['bonusWeight']),
            ], (array) ($d['certifications'] ?? [])),
        ];
    }
    usort($daftar, fn($a, $b) => strcasecmp($a['name'], $b['name']));
    return $daftar;
}

/** Bobot dan ambang penilaian dari koleksi scoring_config (dokumen pertama). */
function kbConfig(): array
{
    $standar = [
        'weight_skill' => 0.60, 'weight_education' => 0.15, 'weight_experience' => 0.15, 'weight_certification' => 0.10,
        'threshold_high' => 75, 'threshold_medium' => 55, 'threshold_low' => 35, 'top_n' => 5,
    ];
    $dok = kbNormalize(mongoFindMany('scoring_config', []))[0] ?? [];
    foreach ($standar as $kunci => $nilai) {
        if (isset($dok[$kunci]) && is_numeric($dok[$kunci])) {
            $standar[$kunci] = (float) $dok[$kunci];
        }
    }
    return $standar;
}

/** Seluruh pengetahuan yang dibutuhkan mesin, dalam satu paket. */
function kbKnowledge(): array
{
    return ['skills' => kbSkills(), 'certifications' => kbCertifications(), 'careers' => kbCareers()];
}
