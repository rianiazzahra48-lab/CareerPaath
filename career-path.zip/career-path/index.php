<?php
// Halaman depan. Yang sudah masuk langsung diarahkan ke halamannya masing-masing.
require_once __DIR__ . '/includes/layout.php';
require_once __DIR__ . '/includes/kb.php';

if ($sudah = currentUser()) {
    header('Location: ' . homeFor($sudah['role'] ?? ''));
    exit;
}

// Contoh karier dari knowledge base (MongoDB). Kalau MongoDB tidak bisa dibaca, bagian ini dilewati.
$karier = [];
$jumlahKarier = 0;
$skillDinilai = [];
$sertifDinilai = [];
try {
    $semua = kbCareers();
    $jumlahKarier = count($semua);
    foreach ($semua as $k) {
        foreach ($k['requirements'] as $r) {
            $skillDinilai[$r['skillCode']] = true;
        }
        foreach ($k['certifications'] as $c) {
            $sertifDinilai[$c['certCode']] = true;
        }
    }
    $karier = array_slice($semua, 0, 6);
} catch (Throwable $err) {
    $karier = [];
}
$jenjang = [1 => 'SMA/SMK', 2 => 'Diploma (D3)', 3 => 'Sarjana (S1/D4)', 4 => 'Magister (S2)', 5 => 'Doktor (S3)'];

pageHeader('Temukan karier yang cocok', [], [], 'landing');
?>
<section class="hero">
    <?= bentuk('hero') ?>
    <div class="wrap hero-in">
        <div>
            <h1>Temukan karier yang paling cocok denganmu</h1>
            <p class="sub">Isi profilmu sekali. Career Path mencocokkannya dengan kebutuhan berbagai posisi kerja, lalu menunjukkan skill mana yang sudah kuat dan mana yang perlu dikembangkan.</p>
            <div class="cta">
                <a class="btn pink big" href="register.php">Mulai analisis gratis</a>
                <a class="btn ghost big" href="login.php">Masuk</a>
            </div>
        </div>
        <div class="mock" aria-label="Contoh tampilan hasil analisis">
            <p class="tag">Contoh tampilan hasil</p>
            <div class="mock-top">
                <div class="mock-ring" style="--p:82"><span>82%</span></div>
                <div><b>Data Analyst</b><small>Sangat cocok dengan profilmu</small></div>
            </div>
            <div class="mock-row"><span>SQL &amp; Basis Data</span><em>Sudah kuat</em><span class="track"><i style="width:100%"></i></span></div>
            <div class="mock-row"><span>Visualisasi Data</span><em class="kurang">Perlu ditingkatkan</em><span class="track"><i class="kurang" style="width:55%"></i></span></div>
            <div class="mock-row"><span>Statistik</span><em class="kurang">Belum dimiliki</em><span class="track"><i class="kurang" style="width:12%"></i></span></div>
        </div>
    </div>
</section>

<section class="section" id="cara-kerja">
    <div class="wrap">
        <h2>Cara kerjanya</h2>
        <p class="kepala">Tiga langkah, tanpa perlu tahu dulu kamu cocok jadi apa.</p>
        <div class="steps">
            <div class="step"><div class="no">1</div><h3>Isi profilmu</h3><p>Catat pendidikan, skill beserta levelnya, sertifikasi, dan pengalaman kerja.</p></div>
            <div class="step"><div class="no">2</div><h3>Sistem mencocokkan</h3><p>Profilmu dibandingkan dengan kebutuhan kompetensi tiap karier di knowledge base.</p></div>
            <div class="step"><div class="no">3</div><h3>Lihat hasilnya</h3><p>Dapatkan rekomendasi karier, persentase kecocokan, dan skill yang masih perlu dikembangkan.</p></div>
        </div>
    </div>
</section>

<?php if ($karier): ?>
<section class="section tint" id="karier">
    <div class="wrap">
        <h2>Karier yang bisa kamu jelajahi</h2>
        <p class="kepala">Semua kebutuhan kompetensi di bawah ini tersimpan di knowledge base dan bisa diperbarui admin kapan saja.</p>
        <div class="kb-stats">
            <div><b><?= $jumlahKarier ?></b>posisi karier</div>
            <div><b><?= count($skillDinilai) ?></b>skill yang dinilai</div>
            <div><b><?= count($sertifDinilai) ?></b>sertifikasi yang dihitung</div>
        </div>
        <div class="jobs">
            <?php foreach ($karier as $k): ?>
                <article class="job">
                    <h3><?= e($k['name']) ?></h3>
                    <p><?= e($k['description']) ?></p>
                    <div class="chips">
                        <span class="chip"><?= count($k['requirements']) ?> skill</span>
                        <span class="chip">Min. <?= e($jenjang[$k['minEducation']] ?? '-') ?></span>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<section class="section" id="teknologi">
    <div class="wrap">
        <h2>Dibangun dengan tiga database</h2>
        <p class="kepala">Setiap database punya tugas sendiri. Mesin penghitung dipisah dari database, dan keduanya berkomunikasi lewat lapisan penghubung.</p>
        <div class="stack">
            <div class="db"><div class="ikon a">My</div><h3>MySQL</h3><p>Menyimpan akun, profil, skill, sertifikasi, pengalaman, dan riwayat hasil analisis.</p></div>
            <div class="db"><div class="ikon b">Mo</div><h3>MongoDB</h3><p>Knowledge base: kebutuhan kompetensi tiap karier, level, bobot, dan aturan penilaian.</p></div>
            <div class="db"><div class="ikon c">Qd</div><h3>Qdrant</h3><p>Pencarian berdasarkan arti. Ketik dengan bahasa sehari-hari, sistem mencari karier dan skill yang paling dekat.</p></div>
        </div>
    </div>
</section>

<section class="cta-band">
    <?= bentuk('cta') ?>
    <div class="wrap">
        <div>
            <h2>Siap tahu kariermu?</h2>
            <p>Daftar gratis dan dapatkan rekomendasi pertamamu dalam beberapa menit.</p>
        </div>
        <a class="btn pink big" href="register.php">Daftar sekarang</a>
    </div>
</section>
<?php pageFooter(true); ?>
