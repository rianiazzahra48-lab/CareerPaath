<?php
/**
 * ALAT BANTU PENGEMBANGAN: mencari fungsi yang dipanggil tetapi tidak ada.
 * Buka: http://localhost:8080/career-path/cek_fungsi.php
 * Hanya bisa dibuka dari komputer sendiri. HAPUS file ini setelah selesai dipakai.
 */
if (!in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'], true)) {
    http_response_code(403);
    exit('Hanya bisa dibuka dari komputer sendiri.');
}
header('Content-Type: text/plain; charset=utf-8');

$akar = __DIR__;
$lewati = ['vendor', 'node_modules', '.git'];

$berkas = [];
$iter = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($akar, FilesystemIterator::SKIP_DOTS));
foreach ($iter as $f) {
    if ($f->getExtension() !== 'php' || $f->getRealPath() === __FILE__) {
        continue;
    }
    $rel = str_replace('\\', '/', substr($f->getPathname(), strlen($akar) + 1));
    $bagian = explode('/', $rel);
    if (array_intersect($lewati, $bagian)) {
        continue;
    }
    $berkas[] = $rel;
}
sort($berkas);

$didefinisikan = [];   // nama fungsi (huruf kecil) => berkas tempat didefinisikan
$dipanggil = [];       // nama fungsi (huruf kecil) => [[berkas, baris, teks baris], ...]

$abaikanSebelum = [T_FUNCTION, T_OBJECT_OPERATOR, T_DOUBLE_COLON, T_NEW, T_CONST, T_CLASS, T_INTERFACE, T_TRAIT, T_EXTENDS, T_IMPLEMENTS, T_NAMESPACE, T_USE, T_INSTANCEOF];
if (defined('T_NULLSAFE_OBJECT_OPERATOR')) {
    $abaikanSebelum[] = T_NULLSAFE_OBJECT_OPERATOR;
}

foreach ($berkas as $rel) {
    $sumber = file_get_contents($akar . '/' . $rel);
    $baris = explode("\n", $sumber);
    $token = token_get_all($sumber);
    $n = count($token);

    $sebelumnya = function (int $i) use ($token) {
        for ($j = $i - 1; $j >= 0; $j--) {
            if (is_array($token[$j]) && in_array($token[$j][0], [T_WHITESPACE, T_COMMENT, T_DOC_COMMENT], true)) {
                continue;
            }
            return $token[$j];
        }
        return null;
    };
    $berikutnya = function (int $i) use ($token, $n) {
        for ($j = $i + 1; $j < $n; $j++) {
            if (is_array($token[$j]) && in_array($token[$j][0], [T_WHITESPACE, T_COMMENT, T_DOC_COMMENT], true)) {
                continue;
            }
            return $token[$j];
        }
        return null;
    };

    for ($i = 0; $i < $n; $i++) {
        if (!is_array($token[$i]) || $token[$i][0] !== T_STRING) {
            continue;
        }
        $nama = strtolower($token[$i][1]);
        $sblm = $sebelumnya($i);
        $brkt = $berikutnya($i);

        // definisi: function nama(
        if (is_array($sblm) && $sblm[0] === T_FUNCTION) {
            $didefinisikan[$nama] = $rel;
            continue;
        }
        // panggilan: nama( , kecuali metode, statis, new, dst.
        if ($brkt === '(' && !(is_array($sblm) && in_array($sblm[0], $abaikanSebelum, true))) {
            $no = $token[$i][2];
            $dipanggil[$nama][] = [$rel, $no, trim($baris[$no - 1] ?? '')];
        }
    }
}

$hilang = [];
foreach ($dipanggil as $nama => $lokasi) {
    if (isset($didefinisikan[$nama]) || function_exists($nama)) {
        continue;
    }
    $hilang[$nama] = $lokasi;
}
ksort($hilang);

echo "PEMINDAI FUNGSI\n";
echo str_repeat('=', 60) . "\n";
echo count($berkas) . " berkas PHP diperiksa, " . count($didefinisikan) . " fungsi buatan sendiri ditemukan.\n\n";

if (!$hilang) {
    echo "Tidak ada fungsi yang dipanggil tetapi hilang. Semuanya aman.\n";
    exit;
}

echo "FUNGSI YANG DIPANGGIL TETAPI TIDAK ADA (" . count($hilang) . "):\n";
echo str_repeat('-', 60) . "\n";
foreach ($hilang as $nama => $lokasi) {
    echo "\n" . $nama . "()  dipanggil " . count($lokasi) . " kali:\n";
    foreach (array_slice($lokasi, 0, 6) as [$rel, $no, $teks]) {
        echo sprintf("   %s:%d   %s\n", $rel, $no, mb_substr($teks, 0, 110));
    }
    if (count($lokasi) > 6) {
        echo "   ... dan " . (count($lokasi) - 6) . " tempat lain\n";
    }
}
echo "\nSalin seluruh tulisan ini dan kirim ke Claude.\n";
