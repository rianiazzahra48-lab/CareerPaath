<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/layout.php';
require_once __DIR__ . '/includes/assessment.php';

$user  = requireUser();
$daftar = listAssessments(getMysqlConnection(), $user['id']);

pageHeader('Riwayat analisis', ['assets/result.css']);
?>
<?php pageBanner('Riwayat analisis', 'Setiap analisis menyimpan salinan profilmu saat itu, jadi kamu bisa melihat perkembangannya.'); ?>

<div class="card">
    <?php if (!$daftar): ?>
        <p>Belum ada analisis.</p>
        <p style="margin-bottom:0"><a class="btn" href="profile.php">Isi profil</a></p>
    <?php endif; ?>
    <?php foreach ($daftar as $r): ?>
        <a class="list-row" href="result.php?id=<?= (int) $r['id'] ?>">
            <div>
                <div class="t"><?= e($r['career_name'] ?? 'Tanpa hasil') ?></div>
                <div class="d"><?= e(date('d M Y, H:i', strtotime($r['created_at']))) ?> - <?= e($r['label'] ?? '') ?></div>
            </div>
            <span class="sc"><?= $r['score'] === null ? '' : e(number_format((float) $r['score'], 0)) . '%' ?></span>
        </a>
    <?php endforeach; ?>
</div>
<?php pageFooter(); ?>
