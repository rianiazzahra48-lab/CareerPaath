<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/assessment.php';

$user = requireUser();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: dashboard.php');
    exit;
}
csrfCheck();

$id = runAssessment(getMysqlConnection(), $user['id']);
if ($id === null) {
    header('Location: profile.php?perlu_skill=1');
    exit;
}
header('Location: result.php?id=' . $id);
exit;
