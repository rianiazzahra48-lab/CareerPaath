<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/mongo.php';
require_once __DIR__ . '/includes/qdrant.php';

echo "<h3>Test Koneksi</h3>";

try {
    $pdo = getMysqlConnection();
    echo "✅ MySQL: OK<br>";
} catch (Exception $e) {
    echo "❌ MySQL: " . $e->getMessage() . "<br>";
}

try {
    $docs = mongoFindMany('careers', []);
    echo "✅ MongoDB: OK (dokumen: " . count($docs) . ")<br>";
} catch (Exception $e) {
    echo "❌ MongoDB: " . $e->getMessage() . "<br>";
    echo "Class: " . get_class($e) . "<br>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
}

$result = qdrantRequest('GET', '/collections');
echo isset($result['result']) ? "✅ Qdrant: OK<br>" : "❌ Qdrant gagal<br>";