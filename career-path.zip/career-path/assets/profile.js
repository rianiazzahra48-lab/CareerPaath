// Tombol "Tambah pengalaman" dan penghitung skill.
(function () {
    var daftar = document.getElementById('exp-list');
    var templat = document.getElementById('exp-template');
    var tombol = document.getElementById('exp-add');

    if (daftar && templat && tombol) {
        tombol.addEventListener('click', function () {
            daftar.appendChild(templat.content.cloneNode(true));
            var judul = daftar.querySelectorAll('input[name="exp_title[]"]');
            judul[judul.length - 1].focus();
        });
    }

    var penghitung = document.getElementById('skill-count');
    function hitung() {
        var n = document.querySelectorAll('.lvl input:checked:not([value="0"])').length;
        var total = document.querySelectorAll('.skill-row').length;
        if (penghitung) penghitung.textContent = n + ' dari ' + total + ' skill dipilih';
    }
    document.addEventListener('change', hitung);
    hitung();
})();
