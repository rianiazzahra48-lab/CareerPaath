// Gelembung chatbot: dibuat lewat JavaScript, semua teks dipasang dengan textContent (aman dari XSS).
(function () {
    var root = document.getElementById('chatbot');
    if (!root) return;

    var csrf = root.getAttribute('data-csrf') || '';
    var KUNCI = 'cp_chat_v1';
    var SAPAAN = {
        from: 'bot',
        blocks: [{ t: 'text', v: 'Halo! Aku asisten karier. Aku menjawab dari knowledge base dan hasil analisis profilmu.' }],
        suggest: ['Karier apa yang paling cocok untukku?', 'Skill apa yang harus kupelajari dulu?', 'Apa itu Data Analyst?', 'Apa bedanya System Analyst dan Data Analyst?']
    };
    var state = muat();
    var sibuk = false;

    if (document.querySelector('.savebar')) root.classList.add('ada-savebar');

    function muat() {
        try {
            var s = JSON.parse(sessionStorage.getItem(KUNCI));
            if (s && Array.isArray(s.msgs)) return s;
        } catch (e) { /* abaikan */ }
        return { open: false, msgs: [SAPAAN] };
    }
    function simpan() {
        try {
            state.msgs = state.msgs.slice(-30);
            sessionStorage.setItem(KUNCI, JSON.stringify(state));
        } catch (e) { /* penyimpanan penuh atau dimatikan */ }
    }
    function el(tag, kelas, teks) {
        var e = document.createElement(tag);
        if (kelas) e.className = kelas;
        if (teks !== undefined) e.textContent = teks;
        return e;
    }

    // ---- kerangka
    var launcher = el('button', 'bot-launcher');
    launcher.type = 'button';
    launcher.setAttribute('aria-label', 'Buka asisten karier');
    launcher.setAttribute('aria-expanded', 'false');
    launcher.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/><circle cx="9" cy="12" r=".6" fill="currentColor"/><circle cx="12.5" cy="12" r=".6" fill="currentColor"/><circle cx="16" cy="12" r=".6" fill="currentColor"/></svg>';

    var panel = el('section', 'bot-panel');
    panel.setAttribute('role', 'dialog');
    panel.setAttribute('aria-label', 'Asisten karier');
    panel.hidden = true;

    var head = el('div', 'bot-head');
    var judul = el('div', 'grow');
    judul.appendChild(el('strong', '', 'Asisten Karier'));
    judul.appendChild(el('small', '', 'Menjawab dari knowledge base'));
    var tombolBaru = el('button', '', 'Mulai ulang'); tombolBaru.type = 'button';
    var tombolTutup = el('button', '', 'Tutup'); tombolTutup.type = 'button';
    tombolTutup.setAttribute('aria-label', 'Tutup asisten karier');
    head.appendChild(judul); head.appendChild(tombolBaru); head.appendChild(tombolTutup);

    var log = el('div', 'bot-log');
    log.setAttribute('aria-live', 'polite');
    var chips = el('div', 'bot-chips');
    var form = el('form', 'bot-form');
    var input = el('input'); input.type = 'text'; input.maxLength = 300; input.autocomplete = 'off';
    input.placeholder = 'Tulis pertanyaanmu...'; input.setAttribute('aria-label', 'Pertanyaan');
    var kirim = el('button', '', 'Kirim'); kirim.type = 'submit';
    form.appendChild(input); form.appendChild(kirim);

    panel.appendChild(head); panel.appendChild(log); panel.appendChild(chips); panel.appendChild(form);
    root.appendChild(panel); root.appendChild(launcher);

    // ---- tampilan pesan
    function gambarPesan(m) {
        var box = el('div', 'bot-msg ' + (m.from === 'user' ? 'user' : 'bot'));
        if (m.from === 'user') { box.textContent = m.text; return box; }
        (m.blocks || []).forEach(function (b) {
            if (b.t === 'text') {
                box.appendChild(el('p', '', b.v));
            } else if (b.t === 'list') {
                var ul = el('ul');
                (b.v || []).forEach(function (x) { ul.appendChild(el('li', '', x)); });
                box.appendChild(ul);
            } else if (b.t === 'link' && /^(https?:\/\/|[a-z_]+\.php)/i.test(b.href)) {
                var a = el('a', 'tautan', b.v + ' \u2192');
                a.href = b.href;
                if (/^https?:/i.test(b.href)) { a.target = '_blank'; a.rel = 'noopener noreferrer'; }
                box.appendChild(a);
            }
        });
        return box;
    }
    function gambarSemua() {
        log.textContent = '';
        state.msgs.forEach(function (m) { log.appendChild(gambarPesan(m)); });
        var terakhir = state.msgs[state.msgs.length - 1];
        chips.textContent = '';
        if (terakhir && terakhir.from === 'bot') {
            (terakhir.suggest || []).forEach(function (s) {
                var b = el('button', '', s); b.type = 'button';
                b.addEventListener('click', function () { tanya(s); });
                chips.appendChild(b);
            });
        }
        log.scrollTop = log.scrollHeight;
    }

    function buka(tampil) {
        state.open = tampil;
        panel.hidden = !tampil;
        launcher.setAttribute('aria-expanded', String(tampil));
        launcher.setAttribute('aria-label', tampil ? 'Tutup asisten karier' : 'Buka asisten karier');
        simpan();
        if (tampil) { gambarSemua(); input.focus(); }
    }

    // ---- kirim pertanyaan
    function tanya(teks) {
        teks = (teks || '').trim();
        if (!teks || sibuk) return;
        sibuk = true;
        input.value = '';
        input.disabled = kirim.disabled = true;
        state.msgs.push({ from: 'user', text: teks });
        gambarSemua();
        chips.textContent = '';
        var tunggu = el('div', 'bot-msg bot diam', 'Mencari di knowledge base...');
        log.appendChild(tunggu); log.scrollTop = log.scrollHeight;

        fetch('chat.php', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
            body: JSON.stringify({ message: teks })
        }).then(function (r) {
            return r.json().catch(function () { return {}; }).then(function (d) { return { ok: r.ok, d: d }; });
        }).then(function (h) {
            if (h.ok && h.d.blocks) {
                state.msgs.push({ from: 'bot', blocks: h.d.blocks, suggest: h.d.suggest || [] });
            } else {
                state.msgs.push({ from: 'bot', blocks: [{ t: 'text', v: h.d.error || 'Maaf, terjadi kesalahan. Coba lagi.' }], suggest: [] });
            }
        }).catch(function () {
            state.msgs.push({ from: 'bot', blocks: [{ t: 'text', v: 'Tidak bisa terhubung ke server. Periksa koneksi lalu coba lagi.' }], suggest: [] });
        }).then(function () {
            sibuk = false;
            input.disabled = kirim.disabled = false;
            simpan(); gambarSemua(); input.focus();
        });
    }

    form.addEventListener('submit', function (e) { e.preventDefault(); tanya(input.value); });
    launcher.addEventListener('click', function () { buka(panel.hidden); });
    tombolTutup.addEventListener('click', function () { buka(false); launcher.focus(); });
    tombolBaru.addEventListener('click', function () { state.msgs = [SAPAAN]; simpan(); gambarSemua(); input.focus(); });
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && !panel.hidden) { buka(false); launcher.focus(); }
    });

    if (state.open) buka(true);
})();
