<?php
// Halaman untuk mengisi (atau mengisi ulang) indeks pencarian di Qdrant.
// Hanya untuk admin. Dijalankan sekali, dan diulang bila knowledge base berubah.
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/admin.php';
require_once __DIR__ . '/includes/qdrant_kb.php';

$user = requireAdmin(getMysqlConnection());

$pesanOk = '';
$pesanError = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    try {
        $jumlah = qkbBangunUlang();
        $pesanOk = "Berhasil. $jumlah data (karier dan skill) sudah masuk ke Qdrant.";
    } catch (Throwable $err) {
        $pesanError = $err->getMessage();
    }
}

$info = null;
$errInfo = '';
try {
    $info = qkbInfo();
} catch (Throwable $err) {
    $errInfo = $err->getMessage();
}

pageHeader('Indeks Qdrant', ['assets/profile.css', 'assets/result.css', 'assets/admin.css']);
?>
<?php pageBanner('Indeks pencarian (Qdrant)', 'Mengisi Qdrant dengan data karier dan skill dari MongoDB, supaya bisa dicari berdasarkan arti.'); ?>
<?php adminNav('qdrant'); ?>

<?php if ($pesanOk): ?><div class="ok"><?= e($pesanOk) ?></div><?php endif; ?>
<?php if ($pesanError): ?><div class="error"><?= e($pesanError) ?></div><?php endif; ?>

<div class="card">
    <h2 style="margin-top:0">Keadaan sekarang</h2>
    <p>Koleksi: <b><?= e(qkbKoleksi()) ?></b><br>Model: <b><?= e(qkbModel()) ?></b> (<?= qkbDimensi() ?> dimensi)</p>
    <?php if ($errInfo): ?>
        <div class="error"><?= e($errInfo) ?></div>
    <?php elseif ($info === null): ?>
        <p>Koleksi belum dibuat.</p>
    <?php else: ?>
        <p>Jumlah data di Qdrant: <b><?= (int) ($info['points_count'] ?? 0) ?></b></p>
    <?php endif; ?>

    <form method="post">
        <?= csrfField() ?>
        <button type="submit"><?= $info === null ? 'Buat dan isi indeks' : 'Isi ulang indeks' ?></button>
    </form>
    <p class="muted">Prosesnya beberapa detik. Isi ulang hanya perlu dilakukan kalau data karier atau skill di MongoDB berubah.</p>
</div>
<?php pageFooter(); ?>
