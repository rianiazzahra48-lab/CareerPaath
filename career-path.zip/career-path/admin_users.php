<?php
// Admin: daftar pengguna dan pengubahan peran (user atau admin).
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/admin.php';

$pdo  = getMysqlConnection();
$user = requireAdmin($pdo);

$cari = mb_substr(trim((string) ($_GET['q'] ?? $_POST['q'] ?? '')), 0, 100);

/* ---------- Mengubah peran ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();

    $id    = (int) ($_POST['id'] ?? 0);
    $peran = (string) ($_POST['peran'] ?? '');

    $q = $pdo->prepare('SELECT id, name, role FROM users WHERE id = ?');
    $q->execute([$id]);
    $target = $q->fetch(PDO::FETCH_ASSOC);

    if (!in_array($peran, ['user', 'admin'], true) || !$target) {
        flashSet('error', 'Permintaan tidak valid.');
    } elseif ($target['role'] === $peran) {
        flashSet('warn', 'Peran ' . $target['name'] . ' sudah ' . $peran . '.');
    } elseif ((int) $target['id'] === (int) $user['id'] && $peran !== 'admin') {
        flashSet('error', 'Kamu tidak bisa menurunkan peran akunmu sendiri. Minta admin lain melakukannya.');
    } else {
        $jumlahAdmin = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn();
        if ($target['role'] === 'admin' && $peran !== 'admin' && $jumlahAdmin <= 1) {
            flashSet('error', 'Harus tetap ada minimal satu admin.');
        } else {
            $pdo->prepare('UPDATE users SET role = ? WHERE id = ?')->execute([$peran, $id]);
            flashSet('ok', 'Peran ' . $target['name'] . ' sekarang ' . $peran . '. Perubahan berlaku saat dia membuka halaman berikutnya.');
        }
    }

    header('Location: admin_users.php' . ($cari !== '' ? '?q=' . rawurlencode($cari) : ''));
    exit;
}

/* ---------- Daftar pengguna ---------- */
$sql = 'SELECT u.id, u.name, u.email, u.role,
               (SELECT COUNT(*) FROM assessments a WHERE a.user_id = u.id) AS n_analisis,
               (SELECT COUNT(*) FROM user_skills s WHERE s.user_id = u.id) AS n_skill
          FROM users u';
$param = [];
if ($cari !== '') {
    $sql .= ' WHERE u.name LIKE ? OR u.email LIKE ?';
    $param = ['%' . $cari . '%', '%' . $cari . '%'];
}
$sql .= ' ORDER BY u.id DESC LIMIT 200';
$q = $pdo->prepare($sql);
$q->execute($param);
$daftar = $q->fetchAll(PDO::FETCH_ASSOC);

pageHeader('Pengguna', ['assets/profile.css', 'assets/result.css', 'assets/admin.css']);
?>
<?php pageBanner('Pengguna', 'Lihat siapa saja yang memakai aplikasi, dan ubah peran admin atau user.'); ?>
<?php adminNav('users'); ?>
<?php flashShow(); ?>

<div class="toolbar">
    <form method="get">
        <input type="text" name="q" value="<?= e($cari) ?>" placeholder="Cari nama atau email" maxlength="100" aria-label="Cari pengguna">
        <button type="submit">Cari</button>
        <?php if ($cari !== ''): ?><a class="btn ghost" href="admin_users.php">Hapus pencarian</a><?php endif; ?>
    </form>
    <span class="muted" style="margin:0"><?= count($daftar) ?> pengguna<?= count($daftar) >= 200 ? ' (200 terbaru)' : '' ?></span>
</div>

<div class="card tbl-wrap">
    <?php if (!$daftar): ?>
        <p class="empty" style="margin:0">Tidak ada pengguna yang cocok.</p>
    <?php else: ?>
        <table class="tbl">
            <tr><th>Nama</th><th>Skill dipilih</th><th>Analisis</th><th>Peran</th></tr>
            <?php foreach ($daftar as $u): $diriSendiri = (int) $u['id'] === (int) $user['id']; ?>
                <tr>
                    <td><b><?= e($u['name']) ?></b><?= $diriSendiri ? ' <span class="pill">kamu</span>' : '' ?><small><?= e($u['email']) ?></small></td>
                    <td><?= (int) $u['n_skill'] ?></td>
                    <td><?= (int) $u['n_analisis'] ?></td>
                    <td>
                        <form method="post" style="display:flex; gap:8px; align-items:center">
                            <?= csrfField() ?>
                            <input type="hidden" name="id" value="<?= (int) $u['id'] ?>">
                            <input type="hidden" name="q" value="<?= e($cari) ?>">
                            <select name="peran" aria-label="Peran <?= e($u['name']) ?>" style="width:auto"<?= $diriSendiri ? ' disabled' : '' ?>>
                                <?= adminOpsi(['user' => 'user', 'admin' => 'admin'], $u['role']) ?>
                            </select>
                            <?php if (!$diriSendiri): ?><button type="submit" class="small">Simpan</button><?php endif; ?>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>
</div>
<?php pageFooter(); ?>
