<?php
// Dashboard admin: ringkasan data. Hanya untuk admin.
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/admin.php';
require_once __DIR__ . '/includes/kb_admin.php';

$pdo  = getMysqlConnection();
$user = requireAdmin($pdo);

function adminAngka(PDO $pdo, string $sql): int
{
    return (int) $pdo->query($sql)->fetchColumn();
}

/* ---------- Data dari MySQL ---------- */
// Semua angka di bawah hanya menghitung akun pengguna biasa (akun admin tidak ikut).
$totalUser     = adminAngka($pdo, "SELECT COUNT(*) FROM users WHERE role <> 'admin'");
$totalAdmin    = adminAngka($pdo, "SELECT COUNT(*) FROM users WHERE role = 'admin'");
$userIsiProfil = adminAngka($pdo, "SELECT COUNT(DISTINCT s.user_id) FROM user_skills s JOIN users u ON u.id = s.user_id WHERE u.role <> 'admin'");
$totalAnalisis = adminAngka($pdo, "SELECT COUNT(*) FROM assessments a JOIN users u ON u.id = a.user_id WHERE u.role <> 'admin'");
$userAnalisis  = adminAngka($pdo, "SELECT COUNT(DISTINCT a.user_id) FROM assessments a JOIN users u ON u.id = a.user_id WHERE u.role <> 'admin'");

// hasil nomor 1 dari setiap analisis milik pengguna biasa
$dariNo1 = "FROM assessment_results r
              JOIN assessments a ON a.id = r.assessment_id
              JOIN users u ON u.id = a.user_id
             WHERE r.rank_no = 1 AND u.role <> 'admin'";

$rataSkor = $pdo->query("SELECT AVG(r.score) $dariNo1")->fetchColumn();

// karier yang paling sering jadi rekomendasi nomor 1
$topKarier = $pdo->query(
    "SELECT r.career_name, COUNT(*) AS jml, AVG(r.score) AS rata $dariNo1
      GROUP BY r.career_code, r.career_name ORDER BY jml DESC, r.career_name LIMIT 8"
)->fetchAll(PDO::FETCH_ASSOC);

// sebaran label kecocokan untuk rekomendasi nomor 1
$sebaranLabel = $pdo->query(
    "SELECT r.label, COUNT(*) AS jml $dariNo1 GROUP BY r.label ORDER BY jml DESC"
)->fetchAll(PDO::FETCH_ASSOC);

// skill yang paling sering kurang (dari celah skill untuk karier nomor 1, 500 analisis terakhir)
$celah = [];
$baris = $pdo->query("SELECT r.detail $dariNo1 ORDER BY r.assessment_id DESC LIMIT 500")
    ->fetchAll(PDO::FETCH_COLUMN);
foreach ($baris as $json) {
    $d = json_decode((string) $json, true);
    foreach ((array) ($d['gaps'] ?? []) as $g) {
        $kode = (string) ($g['skillCode'] ?? '');
        if ($kode === '') {
            continue;
        }
        if (!isset($celah[$kode])) {
            $celah[$kode] = ['name' => (string) ($g['name'] ?? $kode), 'jumlah' => 0, 'kosong' => 0];
        }
        $celah[$kode]['jumlah']++;
        if (($g['status'] ?? '') === 'missing') {
            $celah[$kode]['kosong']++;
        }
    }
}
uasort($celah, fn($a, $b) => $b['jumlah'] <=> $a['jumlah']);
$celah = array_slice($celah, 0, 8, true);

// skill yang paling banyak dimiliki pengguna
$topSkill = $pdo->query(
    "SELECT s.skill_code, COUNT(*) AS jml, AVG(s.level) AS rata
       FROM user_skills s JOIN users u ON u.id = s.user_id
      WHERE u.role <> 'admin'
      GROUP BY s.skill_code ORDER BY jml DESC, s.skill_code LIMIT 8"
)->fetchAll(PDO::FETCH_ASSOC);

// analisis per hari
$perHari = $pdo->query(
    "SELECT DATE(a.created_at) AS hari, COUNT(*) AS jml
       FROM assessments a JOIN users u ON u.id = a.user_id
      WHERE u.role <> 'admin'
      GROUP BY DATE(a.created_at) ORDER BY hari DESC LIMIT 7"
)->fetchAll(PDO::FETCH_ASSOC);

/* ---------- Data dari MongoDB dan Qdrant (boleh gagal, halaman tetap tampil) ---------- */
$namaSkill = [];
$kb = ['careers' => null, 'skills' => null, 'certifications' => null];
$errKb = '';
$peringatan = null;
try {
    foreach (kbSkills() as $s) {
        $namaSkill[$s['code']] = $s['name'];
    }
    foreach ($kb as $koleksi => $_) {
        $kb[$koleksi] = kaJumlah($koleksi);
    }
    $peringatan = kaCekSinkron();
} catch (Throwable $err) {
    $errKb = $err->getMessage();
}

$titikQdrant = null;
$errQdrant = '';
try {
    $info = qkbInfo();
    $titikQdrant = $info === null ? 0 : (int) ($info['points_count'] ?? 0);
} catch (Throwable $err) {
    $errQdrant = $err->getMessage();
}

pageHeader('Admin', ['assets/profile.css', 'assets/result.css', 'assets/admin.css']);
?>
<?php pageBanner('Dashboard admin', 'Ringkasan pengguna, hasil analisis, dan knowledge base. Akun admin tidak ikut dihitung.'); ?>
<?php adminNav('ringkasan'); ?>
<?php flashShow(); ?>

<?php if ($errKb): ?><div class="error">Knowledge base (MongoDB) belum bisa dibaca: <?= e($errKb) ?></div><?php endif; ?>
<?php if ($peringatan): ?><div class="warn"><?= e($peringatan) ?></div><?php endif; ?>

<div class="stats">
    <div class="stat"><b><?= $totalUser ?></b><span>pengguna (<?= $totalAdmin ?> admin)</span></div>
    <div class="stat"><b><?= $userIsiProfil ?></b><span>pengguna sudah mengisi skill</span></div>
    <div class="stat"><b><?= $totalAnalisis ?></b><span>analisis dijalankan oleh <?= $userAnalisis ?> pengguna</span></div>
    <div class="stat"><b><?= $rataSkor === null || $rataSkor === false ? '-' : e(number_format((float) $rataSkor, 0)) . '%' ?></b><span>rata-rata kecocokan karier nomor 1</span></div>
</div>

<div class="cols">
    <div class="card">
        <h2>Karier yang paling sering jadi nomor 1</h2>
        <?php if (!$topKarier): ?><p class="empty">Belum ada analisis.</p><?php endif; ?>
        <?php $maks = $topKarier ? (int) $topKarier[0]['jml'] : 0; ?>
        <?php foreach ($topKarier as $r): ?>
            <div class="rank-row">
                <span class="nm"><?= e($r['career_name']) ?> <small>rata-rata <?= e(number_format((float) $r['rata'], 0)) ?>%</small></span>
                <span class="ct"><?= (int) $r['jml'] ?>x</span>
                <?= adminBatang((float) $r['jml'], (float) $maks) ?>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="card">
        <h2>Skill yang paling sering kurang <small>untuk karier nomor 1</small></h2>
        <?php if (!$celah): ?><p class="empty">Belum ada data celah skill.</p><?php endif; ?>
        <?php $maks = $celah ? (int) reset($celah)['jumlah'] : 0; ?>
        <?php foreach ($celah as $kode => $c): ?>
            <div class="rank-row">
                <span class="nm"><?= e($namaSkill[$kode] ?? $c['name']) ?> <small><?= (int) $c['kosong'] ?> belum punya</small></span>
                <span class="ct"><?= (int) $c['jumlah'] ?>x</span>
                <?= adminBatang((float) $c['jumlah'], (float) $maks) ?>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<div class="cols">
    <div class="card">
        <h2>Skill yang paling banyak dimiliki pengguna</h2>
        <?php if (!$topSkill): ?><p class="empty">Belum ada pengguna yang memilih skill.</p><?php endif; ?>
        <?php $maks = $topSkill ? (int) $topSkill[0]['jml'] : 0; ?>
        <?php foreach ($topSkill as $r): ?>
            <div class="rank-row">
                <span class="nm"><?= e($namaSkill[$r['skill_code']] ?? $r['skill_code']) ?> <small>level rata-rata <?= e(number_format((float) $r['rata'], 1)) ?></small></span>
                <span class="ct"><?= (int) $r['jml'] ?> orang</span>
                <?= adminBatang((float) $r['jml'], (float) $maks) ?>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="card">
        <h2>Tingkat kecocokan karier nomor 1</h2>
        <?php if (!$sebaranLabel): ?><p class="empty">Belum ada analisis.</p><?php endif; ?>
        <?php $maks = $sebaranLabel ? (int) $sebaranLabel[0]['jml'] : 0; ?>
        <?php foreach ($sebaranLabel as $r): ?>
            <div class="rank-row">
                <span class="nm"><?= e($r['label']) ?></span>
                <span class="ct"><?= (int) $r['jml'] ?></span>
                <?= adminBatang((float) $r['jml'], (float) $maks) ?>
            </div>
        <?php endforeach; ?>

        <h2 style="margin-top:22px">Analisis 7 hari terakhir yang ada datanya</h2>
        <?php if (!$perHari): ?><p class="empty">Belum ada analisis.</p><?php endif; ?>
        <?php $maks = 0; foreach ($perHari as $r) { $maks = max($maks, (int) $r['jml']); } ?>
        <?php foreach ($perHari as $r): ?>
            <div class="rank-row">
                <span class="nm"><?= e(date('d M Y', strtotime((string) $r['hari']))) ?></span>
                <span class="ct"><?= (int) $r['jml'] ?></span>
                <?= adminBatang((float) $r['jml'], (float) $maks) ?>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<div class="card">
    <h2>Knowledge base</h2>
    <div class="stats" style="margin-bottom:12px">
        <div class="stat"><b><?= $kb['careers'] ?? '-' ?></b><span>karier (MongoDB)</span></div>
        <div class="stat"><b><?= $kb['skills'] ?? '-' ?></b><span>skill (MongoDB)</span></div>
        <div class="stat"><b><?= $kb['certifications'] ?? '-' ?></b><span>sertifikasi (MongoDB)</span></div>
        <div class="stat"><b><?= $titikQdrant ?? '-' ?></b><span>data di indeks pencarian (Qdrant)</span></div>
    </div>
    <?php if ($errQdrant): ?><div class="warn">Qdrant belum bisa dibaca: <?= e($errQdrant) ?></div><?php endif; ?>
    <div class="form-actions">
        <a class="btn" href="admin_kb.php">Kelola knowledge base</a>
        <a class="btn ghost" href="admin_users.php">Kelola pengguna</a>
    </div>
</div>
<?php pageFooter(); ?>
