<?php
// Pencarian berdasarkan arti: ketik apa saja, sistem mencari karier dan skill yang paling dekat maknanya.
require_once __DIR__ . '/includes/layout.php';
require_once __DIR__ . '/includes/qdrant_kb.php';

$user = requireUser();
$q = trim((string) ($_GET['q'] ?? ''));
$q = mb_substr($q, 0, 200);

$karier = $skill = [];
$error = '';
if ($q !== '') {
    try {
        $karier = qkbCari($q, 3, 'career');
        $skill  = qkbCari($q, 5, 'skill');
    } catch (Throwable $err) {
        $error = $err->getMessage();
    }
}

pageHeader('Cari', ['assets/result.css']);
?>
<?php pageBanner('Cari karier atau skill', 'Ketik dengan bahasa sehari-hari, misalnya "suka membuat tampilan aplikasi" atau "belajar mengolah data".'); ?>

<div class="card">
    <form method="get" style="display:flex; gap:10px; flex-wrap:wrap">
        <input type="text" name="q" value="<?= e($q) ?>" maxlength="200" placeholder="Apa yang ingin kamu cari?" style="flex:1; min-width:220px; margin:0">
        <button type="submit">Cari</button>
    </form>
</div>

<?php if ($error): ?>
    <div class="error" style="margin-top:16px"><?= e($error) ?></div>
<?php elseif ($q !== ''): ?>
    <div class="card" style="margin-top:16px">
        <h2 style="margin-top:0">Karier yang paling dekat</h2>
        <?php if (!$karier): ?><p class="empty">Tidak ada hasil.</p><?php endif; ?>
        <?php foreach ($karier as $h): $p = $h['payload']; ?>
            <div class="learn">
                <b><?= e($p['name'] ?? '') ?></b>
                <span class="lv">Kemiripan <?= e(number_format($h['score'] * 100, 0)) ?>%</span>
                <p><?= e($p['description'] ?? '') ?></p>
            </div>
        <?php endforeach; ?>
    </div>
    <div class="card">
        <h2 style="margin-top:0">Skill yang paling dekat</h2>
        <?php if (!$skill): ?><p class="empty">Tidak ada hasil.</p><?php endif; ?>
        <?php foreach ($skill as $h): $p = $h['payload']; ?>
            <div class="learn">
                <b><?= e($p['name'] ?? '') ?></b>
                <span class="lv"><?= e($p['category'] ?? '') ?> - kemiripan <?= e(number_format($h['score'] * 100, 0)) ?>%</span>
                <?php if (!empty($p['careers'])): ?><p>Dibutuhkan untuk: <?= e(implode(', ', $p['careers'])) ?></p><?php endif; ?>
                <?php if (!empty($p['tip'])): ?><p><?= e($p['tip']) ?></p><?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
<?php pageFooter(); ?>
